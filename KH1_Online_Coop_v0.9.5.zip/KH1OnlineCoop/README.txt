KH1 ONLINE COOP v0.9.5 - TRANSIENT NATIVE DUPLICATE ISOLATION

This build keeps the stable v0.8.5 network/two-instance foundation and tests a safer native second-Sora path.

Player 1 only:
- KH1's normal placement table stays active for the normal room spawn loop.
- The bridge prepares a temporary copy with one extra Sora-resource record in Donald's character slot.
- When KH1 reaches the real Sora SpawnEntity call, the bridge lets the real Sora spawn normally.
- It then swaps in the temporary table for ONE nested SpawnEntity call on the same game thread.
- The original placement-table pointer/count are restored immediately before KH1 continues the room loop.
- After spawn, the bridge performs NO position, rotation, animation, visibility, controller, or cleanup writes.

Player 2 remains network/read-only for this isolation test.

LOCAL TEST
1. Run Local Test - Start Two Instances.bat.
2. Launch KH1 normally when prompted.
3. Wait for both bridge windows to attach.
4. Load the same save/room in both instances.
5. If a second Sora appears on Player 1, leave both instances running for several minutes.

Expected Player 1 console lines include:
  Transient room splice prepared: ... original table remains active.
  Transient native duplicate Sora alive | ... | placement table already restored | NO POST-SPAWN WRITES

If SpawnEntity refuses the duplicate, the bridge will report that the nested call returned null instead of altering the room table permanently.
