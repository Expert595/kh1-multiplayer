$ErrorActionPreference = "Stop"
$ModDir = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))
$GameDir = Split-Path -Parent $ModDir
$bridge = Join-Path $ModDir "bin\KHCoopBridge.exe"
$hostCfg = Join-Path $ModDir "config\local-host.ini"
$clientCfg = Join-Path $ModDir "config\local-client.ini"

if (-not (Test-Path $bridge)) { throw "bin\KHCoopBridge.exe is missing. Run '1 - Setup.bat' or re-extract the package." }
if (-not (Test-Path $hostCfg)) { throw "config\local-host.ini is missing." }
if (-not (Test-Path $clientCfg)) { throw "config\local-client.ini is missing." }

function Get-KH1Processes {
    @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -eq "KINGDOM HEARTS FINAL MIX" } | Sort-Object Id)
}

function Wait-KH1Count([int]$Count, [int]$TimeoutSeconds) {
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        $items = @(Get-KH1Processes)
        if ($items.Count -ge $Count) { return $items }
        Start-Sleep -Milliseconds 500
    } while ((Get-Date) -lt $deadline)
    return @(Get-KH1Processes)
}

function Get-LaunchInfo([int]$ProcessId) {
    $row = Get-CimInstance Win32_Process -Filter "ProcessId = $ProcessId" -ErrorAction SilentlyContinue
    if ($null -eq $row) { return $null }
    $cmd = [string]$row.CommandLine
    $exe = [string]$row.ExecutablePath
    if ([string]::IsNullOrWhiteSpace($cmd)) {
        if ([string]::IsNullOrWhiteSpace($exe)) { return $null }
        $cmd = '"' + $exe + '"'
    }
    return [pscustomobject]@{ ProcessId = [int]$row.ProcessId; CommandLine = $cmd; ExecutablePath = $exe }
}

function Wait-StableKH1LaunchInfo([int]$PreferredProcessId, [int]$TimeoutSeconds) {
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $lastPid = 0
    $stableSamples = 0

    do {
        $items = @(Get-KH1Processes)
        if ($items.Count -gt 0) {
            $ordered = @()
            if ($PreferredProcessId -gt 0) {
                $preferred = @($items | Where-Object { $_.Id -eq $PreferredProcessId })
                if ($preferred.Count -gt 0) { $ordered += $preferred }
            }
            $ordered += @($items | Where-Object { $_.Id -ne $PreferredProcessId } | Sort-Object Id -Descending)

            foreach ($proc in $ordered) {
                $info = Get-LaunchInfo ([int]$proc.Id)
                if ($null -eq $info) { continue }

                if ($lastPid -eq $proc.Id) {
                    $stableSamples++
                } else {
                    $lastPid = [int]$proc.Id
                    $stableSamples = 1
                }

                # Require the same inspectable KH1 PID for ~1 second so Epic hand-off/stub PIDs are ignored.
                if ($stableSamples -ge 4) {
                    return [pscustomobject]@{ Process = $proc; LaunchInfo = $info }
                }
                break
            }
        }
        Start-Sleep -Milliseconds 300
    } while ((Get-Date) -lt $deadline)

    return $null
}

function Duplicate-KH1([int]$HostProcessId, $LaunchInfo) {
    $info = $LaunchInfo
    if ($null -eq $info) {
        $stable = Wait-StableKH1LaunchInfo $HostProcessId 20
        if ($null -eq $stable) { throw "KH1 never became stable/inspectable enough to duplicate its launch command." }
        $HostProcessId = [int]$stable.Process.Id
        $info = $stable.LaunchInfo
    }
    Write-Host "Duplicating the host's real launch command for Player 2..."
    $result = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
        CommandLine = $info.CommandLine
        CurrentDirectory = $GameDir
    }
    if ($null -eq $result -or [int]$result.ReturnValue -ne 0 -or [int]$result.ProcessId -le 0) {
        $code = if ($null -eq $result) { "no result" } else { [string]$result.ReturnValue }
        throw "Windows could not create the second KH1 process. Win32_Process.Create returned $code."
    }

    $newPid = [int]$result.ProcessId
    Write-Host "Second launch request PID: $newPid"

    # Epic/Steam may hand the duplicated launch off to another KH1 PID. Follow the actual second game process,
    # instead of assuming Win32_Process.Create's PID remains the final game PID.
    $deadline = (Get-Date).AddSeconds(20)
    do {
        $items = @(Get-KH1Processes)
        $other = @($items | Where-Object { $_.Id -ne $HostProcessId } | Sort-Object Id -Descending)
        if ($other.Count -gt 0) {
            $candidate = $other[0]
            $stable = Wait-StableKH1LaunchInfo ([int]$candidate.Id) 5
            if ($null -ne $stable -and [int]$stable.Process.Id -ne $HostProcessId) {
                Write-Host "Client stabilized: PID $($stable.Process.Id)"
                return $stable.Process
            }
        }
        Start-Sleep -Milliseconds 300
    } while ((Get-Date) -lt $deadline)

    return $null
}

Write-Host "KH1 Online Coop v0.9.5 - transient native duplicate isolation test"
Write-Host "Player 1 / host:   127.0.0.1:37171"
Write-Host "Player 2 / client: 127.0.0.1:37172"
Write-Host "Player 1: injects one Sora-resource actor into Donald's slot during KH1's own room-load pass"
Write-Host "Player 2: read-only network client"
Write-Host "No post-spawn position, rotation, animation, visibility, cleanup, or controller writes are performed"
Write-Host ""

$oldBridges = @(Get-Process -Name "KHCoopBridge" -ErrorAction SilentlyContinue)
if ($oldBridges.Count -gt 0) {
    Write-Host "Closing $($oldBridges.Count) existing KHCoop bridge process(es)..."
    $oldBridges | Stop-Process -Force
    Start-Sleep -Milliseconds 300
}

$existing = @(Get-KH1Processes)
$hostProcess = $null
$clientProcess = $null

if ($existing.Count -ge 2) {
    $hostProcess = $existing[0]
    $clientProcess = $existing[1]
    Write-Host "Using two already-running KH1 instances: PIDs $($hostProcess.Id) and $($clientProcess.Id)."
} else {
    if ($existing.Count -eq 0) {
        Write-Host "No KH1 instance is running."
        Write-Host "Launch KINGDOM HEARTS FINAL MIX normally through Epic/Steam now."
        Write-Host "This window will wait for it and continue automatically."
        Write-Host ""
        $existing = @(Wait-KH1Count 1 300)
        if ($existing.Count -lt 1) {
            throw "Timed out waiting for the first KH1 instance. Start Local Test again and launch KH1 normally when asked."
        }
    }

    $hostProcess = $existing[0]
    Write-Host "KH1 process detected: PID $($hostProcess.Id). Waiting for Epic/Steam launch hand-off to settle..."
    $stableHost = Wait-StableKH1LaunchInfo ([int]$hostProcess.Id) 20
    if ($null -eq $stableHost) {
        throw "KH1 was detected, but Windows never exposed a stable inspectable game process within 20 seconds."
    }
    $hostProcess = $stableHost.Process
    Write-Host "Host stabilized: PID $($hostProcess.Id)"
    $clientProcess = Duplicate-KH1 ([int]$hostProcess.Id) $stableHost.LaunchInfo
}

if ($null -eq $clientProcess) {
    throw "The duplicated KH1 process exited during startup. The platform/game is still enforcing a second-instance restriction after the real launch arguments were reused."
}

$live = @(Wait-KH1Count 2 5)
if ($live.Count -lt 2) {
    throw "Only one KH1 process remained running. The second-instance restriction is still active."
}

# Refresh exact process objects in case the launcher spawned/replaced one of them.
$live = @(Get-KH1Processes)
if ($live.Count -ge 2) {
    if (-not ($live.Id -contains $hostProcess.Id)) { $hostProcess = $live[0] }
    if (-not ($live.Id -contains $clientProcess.Id)) {
        $clientProcess = @($live | Where-Object { $_.Id -ne $hostProcess.Id })[0]
    }
}

Write-Host "Host PID: $($hostProcess.Id)"
Write-Host "Client PID: $($clientProcess.Id)"
Write-Host "Starting one bridge per exact game PID..."

$hostArgs = @("-config", "`"$hostCfg`"", "-pid", "$($hostProcess.Id)")
$clientArgs = @("-config", "`"$clientCfg`"", "-pid", "$($clientProcess.Id)")
Start-Process -FilePath $bridge -WorkingDirectory $ModDir -ArgumentList $hostArgs
Start-Process -FilePath $bridge -WorkingDirectory $ModDir -ArgumentList $clientArgs

Write-Host ""
Write-Host "Local native-spawn isolation test started."
Write-Host "Wait for BOTH bridges to attach before loading the saves."
Write-Host "Only Player 1 will receive the extra room-loaded Sora-resource actor. Player 2 remains read-only."
Write-Host "Do not expect the extra Sora to follow Player 2 in this build. This test is only checking whether the native room-loaded actor can stay alive without any later writes."
Write-Host "A controller may be read by both windows, so keyboard/mouse is cleaner for independent input tests."
Write-Host "Avoid saving from both instances at exactly the same time because both use the same KH1 save directory."
