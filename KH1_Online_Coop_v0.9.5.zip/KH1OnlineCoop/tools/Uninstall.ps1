$ErrorActionPreference = "SilentlyContinue"
$ModDir = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))
$GameDir = Split-Path -Parent $ModDir

Get-Process -Name "KHCoopBridge" -ErrorAction SilentlyContinue | Stop-Process -Force

$docs = [Environment]::GetFolderPath("MyDocuments")
$roots = @(
    (Join-Path $docs "KINGDOM HEARTS HD 1.5+2.5 ReMIX\scripts\kh1"),
    (Join-Path $docs "My Games\KINGDOM HEARTS HD 1.5+2.5 ReMIX\scripts\kh1")
)
foreach ($scriptDir in $roots) {
    Remove-Item -Force (Join-Path $scriptDir "KHCoop.lua") -ErrorAction SilentlyContinue
    Remove-Item -Force (Join-Path $scriptDir "khcoop_profiles.lua") -ErrorAction SilentlyContinue
    Remove-Item -Force (Join-Path $scriptDir "khcoop_client.ini") -ErrorAction SilentlyContinue
}

$luaConfig = Join-Path $GameDir "LuaBackend.toml"
$luaBackup = "$luaConfig.khcoop-backup"
if (Test-Path $luaBackup) {
    Copy-Item -Force $luaBackup $luaConfig
    Remove-Item -Force $luaBackup
} elseif (Test-Path $luaConfig) {
    try {
        $text = Get-Content -Raw $luaConfig
        if ($text -match "KHCOOP_NOOP_LUABACKEND_CONFIG") { Remove-Item -Force $luaConfig }
    } catch {}
}

Write-Host "KH1 Online Coop runtime cleanup complete."
