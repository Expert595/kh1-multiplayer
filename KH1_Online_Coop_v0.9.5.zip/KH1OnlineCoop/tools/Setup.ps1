$ErrorActionPreference = "Stop"
$ModDir = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))
$GameDir = Split-Path -Parent $ModDir
$gameExe = Join-Path $GameDir "KINGDOM HEARTS FINAL MIX.exe"
$bridge = Join-Path $ModDir "bin\KHCoopBridge.exe"
$config = Join-Path $ModDir "config\khcoop.ini"

if (-not (Test-Path $gameExe)) {
    throw "Put the KH1OnlineCoop folder directly inside the Kingdom Hearts 1.5+2.5 game folder. KINGDOM HEARTS FINAL MIX.exe was not found beside it."
}
if (-not (Test-Path $bridge)) { throw "bin\KHCoopBridge.exe is missing. Re-extract the complete package." }
if (-not (Test-Path $config)) { throw "config\khcoop.ini is missing. Re-extract the complete package." }

Write-Host "KH1 Online Coop v0.9.1 setup"
Write-Host "Game folder: $GameDir"
Write-Host "Mod folder:  $ModDir"
Write-Host ""

# Preserve the user's old online settings before removing the previous scattered layout.
$oldConfig = Join-Path $GameDir "KHCoop\khcoop.ini"
if (Test-Path $oldConfig) {
    Copy-Item -Force $oldConfig $config
    Write-Host "Migrated previous online configuration into config\khcoop.ini."
}

# Remove only files positively identified as older KH1 Online Coop launchers/scripts.
$legacyNames = @(
    "Install-KHCoop.bat", "Install-KHCoop.ps1",
    "Configure-KHCoop.bat", "Configure-KHCoop.ps1",
    "Start-KHCoop.bat", "Start-Local-Test.bat", "Start-Local-Test.ps1",
    "Uninstall-KHCoop.bat", "Uninstall-KHCoop.ps1"
)
foreach ($name in $legacyNames) {
    $path = Join-Path $GameDir $name
    if (-not (Test-Path $path)) { continue }
    $ours = $false
    try {
        $text = Get-Content -Raw $path -ErrorAction Stop
        if ($text -match "KHCoop|KH1 Online Coop|KH1 Coop") { $ours = $true }
    } catch {}
    if ($ours) {
        Remove-Item -Force $path
        Write-Host "Removed old root file: $name"
    } else {
        Write-Host "Left unrelated root file untouched: $name"
    }
}

$oldFolder = Join-Path $GameDir "KHCoop"
if (Test-Path $oldFolder) {
    if ((Test-Path (Join-Path $oldFolder "KHCoopBridge.exe")) -or (Test-Path (Join-Path $oldFolder "khcoop.ini"))) {
        Remove-Item -Recurse -Force $oldFolder
        Write-Host "Removed old KHCoop folder from the game root."
    }
}

# Remove obsolete Lua runtime files from older builds.
$docs = [Environment]::GetFolderPath("MyDocuments")
$legacyLuaRoots = @(
    (Join-Path $docs "KINGDOM HEARTS HD 1.5+2.5 ReMIX\scripts\kh1"),
    (Join-Path $docs "My Games\KINGDOM HEARTS HD 1.5+2.5 ReMIX\scripts\kh1")
)
foreach ($dir in $legacyLuaRoots) {
    foreach ($name in @("KHCoop.lua", "khcoop_profiles.lua", "khcoop_client.ini")) {
        $path = Join-Path $dir $name
        if (Test-Path $path) { Remove-Item -Force $path }
    }
}

# Restore or silence LuaBackend only when an older KHCoop build left it behind.
$luaConfig = Join-Path $GameDir "LuaBackend.toml"
$luaBackup = "$luaConfig.khcoop-backup"
if (Test-Path $luaBackup) {
    Copy-Item -Force $luaBackup $luaConfig
    Remove-Item -Force $luaBackup
    Write-Host "Restored the LuaBackend.toml that existed before KHCoop."
} elseif (Test-Path $luaConfig) {
    try {
        $text = Get-Content -Raw $luaConfig
        if ($text -match "KHCOOP_NOOP_LUABACKEND_CONFIG") {
            # Keep this harmless config only if the old hook DLL is still present, otherwise remove it.
            if (-not (Test-Path (Join-Path $GameDir "DBGHELP.dll"))) {
                Remove-Item -Force $luaConfig
            }
        }
    } catch {}
}

$dbghelp = Join-Path $GameDir "DBGHELP.dll"
if ((Test-Path $dbghelp) -and -not (Test-Path $luaConfig)) {
    $gameDocs = "KINGDOM HEARTS HD 1.5+2.5 ReMIX"
    if (Test-Path (Join-Path $GameDir "steam_api64.dll")) {
        $gameDocs = "My Games/KINGDOM HEARTS HD 1.5+2.5 ReMIX"
    }
    $noopToml = @"
# KHCOOP_NOOP_LUABACKEND_CONFIG
[kh1]
scripts = [{ path = "KHCoopDisabledLua", relative = true }]
exe = "KINGDOM HEARTS FINAL MIX.exe"
game_docs = "$gameDocs"
"@
    [System.IO.File]::WriteAllText($luaConfig, $noopToml, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "Silenced the legacy LuaBackend hook left by an older KHCoop build."
}

Write-Host ""
Write-Host "Setup complete. The game root now only needs the KH1OnlineCoop folder for this mod."
Write-Host "Use '2 - Configure Online.bat' for two-PC play, or 'Local Test - Start Two Instances.bat' for one-PC testing."
