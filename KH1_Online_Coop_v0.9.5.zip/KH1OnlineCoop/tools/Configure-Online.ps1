$ErrorActionPreference = "Stop"
$ModDir = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))
$config = Join-Path $ModDir "config\khcoop.ini"
if (-not (Test-Path $config)) { throw "config\khcoop.ini was not found." }

Write-Host "KH1 Online Coop v0.9.1 - online setup"
Write-Host "Enter the OTHER player's Radmin VPN address (normally 26.x.x.x)."
Write-Host ""

$id = Read-Host "This PC player number (1 or 2)"
if ($id -ne "1" -and $id -ne "2") { throw "Player number must be 1 or 2." }

$peerIp = (Read-Host "Other player's Radmin IP (example 26.12.34.56)").Trim()
$parsed = $null
if (-not [System.Net.IPAddress]::TryParse($peerIp, [ref]$parsed)) { throw "That is not a valid IP address." }
if ($parsed.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) { throw "Use an IPv4 address." }
if ($peerIp.StartsWith("127.")) { throw "127.0.0.1 is reserved for the one-PC local test. Enter the other player's Radmin address." }

$key = Read-Host "Session key (must be exactly the same on both PCs)"
if ([string]::IsNullOrWhiteSpace($key)) { throw "Session key cannot be blank." }

$text = @"
# KH1 Online Coop v0.9.1 - online configuration
listen_port=37171
peer_addr=${peerIp}:37171
player_id=$id
session_key=$key
target_instance=1
target_pid=0
send_hz=30
profile=0
proxy=auto
smoothing=0.42
snap_distance=900
hide_during_cutscene=true
sync_animation=true
spawn_delay_ms=3500
animation_warmup_ms=1500
visual_sync=true
spawn_only=false
existing_actor_only=true
force_party_member=false
reserved_party=donald
"@
[System.IO.File]::WriteAllText($config, $text, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ""
Write-Host "Saved online configuration."
Write-Host "Next: run '3 - Start Online.bat', then launch KH1 normally."
