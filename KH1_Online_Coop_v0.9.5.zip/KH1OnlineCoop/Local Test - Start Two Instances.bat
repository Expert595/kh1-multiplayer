@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Start-Local-Test.ps1"
if errorlevel 1 (
  echo.
  echo Local test failed. Read the error above.
  pause
)
