package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"flag"
	"fmt"
	"math"
	"net"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

const (
	processName = "KINGDOM HEARTS FINAL MIX.exe"
	magic       = uint32(0x504F4F43) // COOP
	protocol    = uint32(5)
	stateSize   = 0x60

	stWorld     = 0x00
	stRoom      = 0x02
	stValid     = 0x04
	stCutscene  = 0x05
	stBattle    = 0x06
	stFlags     = 0x07
	stX         = 0x08
	stY         = 0x0C
	stZ         = 0x10
	stAnim      = 0x14
	stHP        = 0x18
	stMaxHP     = 0x1C
	stInput     = 0x20
	stTick      = 0x24
	stAnimTime  = 0x28
	stForceAnim = 0x2C
	stAnimSpeed = 0x30
	stAirborne  = 0x34
	stRotW      = 0x38
	stRotX      = 0x3C
	stRotY      = 0x40
	stRotZ      = 0x44

	processVMOperation   = 0x0008
	processVMRead        = 0x0010
	processVMWrite       = 0x0020
	processQueryInfo     = 0x0400
	synchronize          = 0x00100000
	memCommit            = 0x00001000
	memReserve           = 0x00002000
	pageReadWrite        = 0x04
	pageExecuteReadWrite = 0x40

	placementRecordSize = 0x78
	placementIDOff      = 0x00
	placementPosXOff    = 0x1C
	placementPosYOff    = 0x20
	placementPosZOff    = 0x24
	placementCharIDOff  = 0x4C
	entityOccFlagOff    = 0x374
	entityPoolStride    = 0x4B0

	th32csSnapProcess  = 0x00000002
	th32csSnapModule   = 0x00000008
	th32csSnapModule32 = 0x00000010

	waitTimeout = 0x00000102
)

const epicLaunchHash = "5afda9b9b5903b16c2310b4bc08bc5e635432e0c8b0fe5600c5a2c6a020aca81"

type Config struct {
	ListenPort         int
	TargetInstance     int
	TargetPID          uint32
	PeerAddr           string
	PlayerID           uint32
	SessionKey         string
	SendHz             int
	Profile            uint32
	Proxy              string
	Smoothing          float32
	SnapDistance       float32
	HideDuringCutscene bool
	SyncAnimation      bool
	SpawnDelayMS       int
	AnimationWarmupMS  int
	VisualSync         bool
	SpawnOnly          bool
	ExistingActorOnly  bool
	ForcePartyMember   bool
	ReservedParty      string
}

type Profile struct {
	ID                  uint32
	Name                string
	World               uintptr
	Room                uintptr
	SoraPointer         uintptr
	SoraObjPointer      uintptr
	DonaldPointer       uintptr
	GoofyPointer        uintptr
	EntityPoolBase      uintptr
	PlacementTablePtr   uintptr
	PlacementTableCount uintptr
	SpawnEntity         uintptr
	SoraHP              uintptr
	MaxHP               uintptr
	Cutscene            uintptr
	InCutscene          uintptr
	InputAddress        uintptr
	PartyConfig         uintptr
	PartyRuntime        uintptr
}

var profiles = map[uint32]Profile{
	1: {
		ID: 1, Name: "Epic 1.0.0.0 (2021 launch build)",
		World: 0x233CADC, Room: 0x233CB44, SoraPointer: 0x2534680, SoraObjPointer: 0x2D33900,
		DonaldPointer: 0x2D33908, GoofyPointer: 0x2D33910, EntityPoolBase: 0x2D33920,
		PlacementTablePtr: 0x2967CB0, PlacementTableCount: 0x2967CA8, SpawnEntity: 0x28C3E0,
		SoraHP: 0x2D592CC, MaxHP: 0x2DE59D6,
		Cutscene: 0x233AE74, InCutscene: 0x2378B60, InputAddress: 0x233D034,
		PartyConfig: 0x2DE5E5F, PartyRuntime: 0x2E1CBE5,
	},
	2: {
		ID: 2, Name: "Steam 1.0.0.2 (Global)",
		World: 0x233FE94, Room: 0x233FE8C, SoraPointer: 0x2537E48, SoraObjPointer: 0x2D37280,
		DonaldPointer: 0x2D37288, GoofyPointer: 0x2D37290, EntityPoolBase: 0x2D372A0,
		PlacementTablePtr: 0x296B630, PlacementTableCount: 0x296B628, SpawnEntity: 0x290D60,
		SoraHP: 0x2D5CC4C, MaxHP: 0x2DE9366,
		Cutscene: 0x233E808, InCutscene: 0x23AB2D0, InputAddress: 0x23407B4,
		PartyConfig: 0x2DE97EF, PartyRuntime: 0x2E205A5,
	},
	3: {
		ID: 3, Name: "Epic 1.0.0.10 (Global)",
		World: 0x2340ECC, Room: 0x2340EC4, SoraPointer: 0x2538A10, SoraObjPointer: 0x2D37C80,
		DonaldPointer: 0x2D37C88, GoofyPointer: 0x2D37C90, EntityPoolBase: 0x2D37CA0,
		PlacementTablePtr: 0x296C030, PlacementTableCount: 0x296C028, SpawnEntity: 0x28EBD0,
		SoraHP: 0x2D5D64C, MaxHP: 0x2DE9D66,
		Cutscene: 0x233F1F4, InCutscene: 0x237CEE0, InputAddress: 0x23413B4,
		PartyConfig: 0x2DEA1EF, PartyRuntime: 0x2E20F65,
	},
}

type processEntry32 struct {
	Size            uint32
	Usage           uint32
	ProcessID       uint32
	DefaultHeapID   uintptr
	ModuleID        uint32
	Threads         uint32
	ParentProcessID uint32
	PriClassBase    int32
	Flags           uint32
	ExeFile         [260]uint16
}

type moduleEntry32 struct {
	Size         uint32
	ModuleID     uint32
	ProcessID    uint32
	GlblcntUsage uint32
	ProccntUsage uint32
	ModBaseAddr  uintptr
	ModBaseSize  uint32
	HModule      uintptr
	SzModule     [256]uint16
	SzExePath    [260]uint16
}

type processRef struct {
	pid        uint32
	handle     syscall.Handle
	moduleBase uintptr
	exePath    string
}

type packet struct {
	Magic       uint32
	Protocol    uint32
	SessionHash uint64
	PlayerID    uint32
	Profile     uint32
	Sequence    uint32
	State       [stateSize]byte
}

type proxyState struct {
	ptr       uintptr
	name      string
	lastWrite time.Time
}

// roomPartyInjectionHook pauses KH1 for a few milliseconds immediately before its native
// placement-table spawn loop so the bridge can prepare a temporary extended copy of the table.
// The original table remains active for the normal room loop. When KH1 reaches Sora's own
// SpawnEntity call, a second hook briefly swaps in the temporary table for one nested SpawnEntity
// call, then restores the original table/count before the room loop continues.
type roomPartyInjectionHook struct {
	patchAddr       uintptr
	resumeAddr      uintptr
	skipAddr        uintptr
	codeAddr        uintptr
	spawnPatchAddr  uintptr
	spawnResumeAddr uintptr
	spawnCodeAddr   uintptr
	controlAddr     uintptr
	original        []byte
	spawnOriginal   []byte
	stop            chan struct{}
	done            chan struct{}
	bypass          *conditionalPartyBypass

	mu            sync.RWMutex
	puppetID      uint32
	injectedTable uintptr
	originalTable uintptr
	originalCount uint32
	injectedAt    time.Time
}

// conditionalPartyBypass leaves KH1's normal Sora constructor untouched for the real player,
// but skips the local player/party registration block only when the entity being constructed
// has our injected placement ID. The room loader still performs the rest of normal Sora setup.
type conditionalPartyBypass struct {
	patchAddr uintptr
	codeAddr  uintptr
	idAddr    uintptr
	original  []byte
}

// mainThreadGate executes selected game functions from KH1's own frame thread.
type mainThreadGate struct {
	codeAddr      uintptr
	dataAddr      uintptr
	frameEntry    uintptr
	originalFrame uintptr
}

type soraCloneState struct {
	ptr             uintptr
	id              uint32
	world           uint16
	room            uint16
	hidden          bool
	scale           [3]float32
	spawnTried      bool
	donorCharID     uint16
	donorRecordID   uint32
	partyBypass     bool
	lastRemoteAnim  byte
	lastRemoteForce byte
	animInitialized bool
	lastAnimApply   time.Time
	spawnedAt       time.Time
	placementTable  uintptr
	originalTable   uint64
	originalCount   uint32
}

var (
	kernel32                     = syscall.NewLazyDLL("kernel32.dll")
	procCreateToolhelp32Snapshot = kernel32.NewProc("CreateToolhelp32Snapshot")
	procProcess32FirstW          = kernel32.NewProc("Process32FirstW")
	procProcess32NextW           = kernel32.NewProc("Process32NextW")
	procModule32FirstW           = kernel32.NewProc("Module32FirstW")
	procModule32NextW            = kernel32.NewProc("Module32NextW")
	procOpenProcess              = kernel32.NewProc("OpenProcess")
	procVirtualAllocEx           = kernel32.NewProc("VirtualAllocEx")
	procVirtualProtectEx         = kernel32.NewProc("VirtualProtectEx")
	procFlushInstructionCache    = kernel32.NewProc("FlushInstructionCache")
	procReadProcessMemory        = kernel32.NewProc("ReadProcessMemory")
	procWriteProcessMemory       = kernel32.NewProc("WriteProcessMemory")
	procWaitForSingleObject      = kernel32.NewProc("WaitForSingleObject")
	procCloseHandle              = kernel32.NewProc("CloseHandle")
)

func main() {
	exe, err := os.Executable()
	if err != nil {
		fatal(err)
	}
	baseDir := filepath.Dir(exe)
	configArg := flag.String("config", "khcoop.ini", "config file name/path")
	pidArg := flag.Uint("pid", 0, "attach to an exact KH1 PID")
	instanceArg := flag.Int("instance", 0, "attach to KH1 instance number, ordered by PID")
	flag.Parse()

	configPath := *configArg
	if !filepath.IsAbs(configPath) {
		configPath = filepath.Join(baseDir, configPath)
	}
	cfg, err := loadConfig(configPath)
	if err != nil {
		fatal(err)
	}
	if *pidArg != 0 {
		cfg.TargetPID = uint32(*pidArg)
	}
	if *instanceArg > 0 {
		cfg.TargetInstance = *instanceArg
	}

	fmt.Printf("KHCoop Bridge v0.9.5 | Player %d | UDP %d\n", cfg.PlayerID, cfg.ListenPort)
	if cfg.VisualSync && cfg.ExistingActorOnly {
		fmt.Println("Runtime mode: transient native room-spawn duplicate diagnostic. Player 1 keeps KH1's original placement table active, briefly swaps a temporary extended copy only for one nested SpawnEntity call, then restores it immediately; NO post-spawn writes.")
	} else if cfg.VisualSync && cfg.SpawnOnly {
		fmt.Println("Runtime mode: SPAWN-ONLY diagnostic. One second-Sora constructor call, then NO further KH1 writes.")
	} else if cfg.VisualSync {
		fmt.Println("Runtime mode: second-Sora network puppet + multi-instance support (visual sync ON).")
	} else {
		fmt.Println("Runtime mode: network-only diagnostic mode (NO game-memory writes, NO second-Sora spawning).")
	}
	if cfg.TargetPID != 0 {
		fmt.Printf("Target: exact KH1 PID %d\n", cfg.TargetPID)
	} else {
		fmt.Printf("Target: KH1 instance %d (instances are ordered by PID)\n", cfg.TargetInstance)
	}
	printLocalIPv4s()
	fmt.Println("Waiting for KINGDOM HEARTS FINAL MIX.exe...")

	for {
		p, err := findProcessTarget(processName, cfg.TargetPID, cfg.TargetInstance)
		if err != nil {
			time.Sleep(time.Second)
			continue
		}
		fmt.Printf("Attached to KH1 (PID %d)\n", p.pid)
		prof, err := detectProfile(p, cfg.Profile)
		if err != nil {
			fmt.Printf("Unsupported KH1 build: %v\n", err)
			closeHandle(p.handle)
			time.Sleep(2 * time.Second)
			continue
		}
		fmt.Printf("Local build: %s | profile %d\n", prof.Name, prof.ID)
		err = runSession(p, cfg, prof)
		closeHandle(p.handle)
		if err != nil {
			fmt.Printf("Session ended: %v\n", err)
		} else {
			fmt.Println("KH1 closed.")
		}
		fmt.Println("Waiting for KINGDOM HEARTS FINAL MIX.exe...")
		time.Sleep(time.Second)
	}
}

func printLocalIPv4s() {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return
	}
	fmt.Println("Local IPv4 addresses:")
	seen := false
	for _, a := range addrs {
		ipnet, ok := a.(*net.IPNet)
		if !ok || ipnet.IP == nil || ipnet.IP.IsLoopback() {
			continue
		}
		ip := ipnet.IP.To4()
		if ip == nil {
			continue
		}
		seen = true
		if ip[0] == 26 {
			fmt.Printf("  %s  (likely Radmin VPN)\n", ip.String())
		} else {
			fmt.Printf("  %s\n", ip.String())
		}
	}
	if !seen {
		fmt.Println("  none detected")
	}
}

func detectProfile(p processRef, forced uint32) (Profile, error) {
	if forced != 0 {
		prof, ok := profiles[forced]
		if !ok {
			return Profile{}, fmt.Errorf("unknown forced profile %d", forced)
		}
		return prof, nil
	}

	if p.exePath != "" {
		if hash, err := sha256File(p.exePath); err == nil && hash == epicLaunchHash {
			return profiles[1], nil
		}
	}

	if b, err := readUint8(p.handle, p.moduleBase+0x4698D2); err == nil && b == 106 {
		return profiles[2], nil
	}
	if b, err := readUint8(p.handle, p.moduleBase+0x46A822); err == nil && b == 106 {
		return profiles[3], nil
	}

	return Profile{}, errors.New("profile auto-detection did not match Epic 1.0.0.0, Steam 1.0.0.2, or Epic 1.0.0.10")
}

func sha256File(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(data)
	return fmt.Sprintf("%x", h[:]), nil
}

func runSession(p processRef, cfg Config, prof Profile) error {
	localUDP := &net.UDPAddr{IP: net.IPv4zero, Port: cfg.ListenPort}
	conn, err := net.ListenUDP("udp4", localUDP)
	if err != nil {
		return fmt.Errorf("listen UDP %d: %w", cfg.ListenPort, err)
	}
	defer conn.Close()

	var peer *net.UDPAddr
	if strings.TrimSpace(cfg.PeerAddr) != "" {
		peer, err = net.ResolveUDPAddr("udp4", cfg.PeerAddr)
		if err != nil {
			return fmt.Errorf("peer_addr: %w", err)
		}
		fmt.Printf("Peer: %s\n", peer.String())
		if peer.IP.IsLoopback() {
			if cfg.TargetInstance > 1 || cfg.ListenPort != 37171 {
				fmt.Println("Loopback peer detected: local two-instance test mode.")
			} else {
				fmt.Println("Loopback peer detected. This is valid for local testing; for Radmin use the OTHER PC's 26.x.x.x address.")
			}
		}
	} else {
		fmt.Println("peer_addr is empty. Bridge is listening only.")
	}

	incoming := make(chan packet, 64)
	go receiveLoop(conn, cfg, incoming)

	tick := time.NewTicker(time.Second / 60)
	defer tick.Stop()
	sendEvery := time.Second / time.Duration(cfg.SendHz)
	lastSend := time.Time{}
	sessionHash := hashSession(cfg.SessionKey)

	var sendSeq uint32
	var lastPeer time.Time
	var remote packet
	haveRemote := false
	peerWasConnected := false
	warnedNoPeer := false
	warnedNoProxy := false
	proxy := proxyState{}
	nativePuppet := soraCloneState{}

	var roomInject *roomPartyInjectionHook
	if cfg.VisualSync && cfg.ExistingActorOnly && cfg.PlayerID == 1 {
		h, e := installRoomPartyInjectionHook(p, prof)
		if e != nil {
			fmt.Printf("Native room-load puppet hook unavailable: %s\n", e.Error())
		} else {
			roomInject = h
			fmt.Println("Transient native duplicate hook armed on Player 1 only. KH1's placement-table pointer stays original except during one nested SpawnEntity call, then is restored immediately.")
		}
	}
	defer func() {
		if roomInject != nil {
			roomInject.uninstall(p)
		}
	}()
	var localTick uint32
	var remoteProfile uint32
	lastLocalValid := false

	var gate *mainThreadGate
	var gateLastTry time.Time
	gateReadyPrinted := false
	gateLastErr := ""
	defer func() {
		if gate != nil {
			gate.uninstall(p)
		}
	}()

	clone := soraCloneState{}
	var cloneLastTry time.Time
	cloneLastErr := ""
	cloneSpawnPrinted := false
	var showStableSince time.Time
	waitingForStablePrinted := false

	for {
		select {
		case rp := <-incoming:
			remote = rp
			haveRemote = true
			lastPeer = time.Now()
			if remoteProfile == 0 || remoteProfile != rp.Profile {
				remoteProfile = rp.Profile
				if rprof, ok := profiles[rp.Profile]; ok {
					fmt.Printf("Receiving Player %d | remote build: %s | profile %d\n", rp.PlayerID, rprof.Name, rp.Profile)
				} else {
					fmt.Printf("Receiving Player %d | remote profile %d\n", rp.PlayerID, rp.Profile)
				}
			}
		case now := <-tick.C:
			if !processAlive(p.handle) {
				return nil
			}

			localTick++
			localState, valid, err := readLocalState(p, prof, localTick)
			if err != nil {
				if !processAlive(p.handle) {
					return nil
				}
				continue
			}
			localWorld := binary.LittleEndian.Uint16(localState[stWorld:])
			localRoom := binary.LittleEndian.Uint16(localState[stRoom:])
			if valid && !lastLocalValid {
				fmt.Printf("Local Sora state active | world %d room %d\n", localWorld, localRoom)
			}
			lastLocalValid = valid

			// Room transitions destroy/recycle room actors. Never keep an old clone pointer across them.
			// If the clone dies while the room is still active, safely restore our extended placement table.
			if clone.ptr != 0 && !cfg.SpawnOnly {
				roomChanged := clone.world != localWorld || clone.room != localRoom
				alive := cloneEntityAlive(p, &clone)
				if roomChanged || !alive {
					if !roomChanged {
						releaseClonePlacement(p, prof, &clone)
					}
					clone = soraCloneState{}
					cloneSpawnPrinted = false
					cloneLastErr = ""
					warnedNoProxy = false
				}
			}

			connected := haveRemote && !lastPeer.IsZero() && now.Sub(lastPeer) < 2*time.Second
			if connected != peerWasConnected {
				if connected {
					fmt.Println("Peer connected. Game state is syncing.")
					warnedNoPeer = false
				} else if peerWasConnected {
					fmt.Println("Peer timed out.")
					proxy = proxyState{}
					nativePuppet = soraCloneState{}
					if clone.ptr != 0 && !cfg.SpawnOnly {
						setCloneHidden(p, &clone, true)
					}
				}
				peerWasConnected = connected
			}

			if peer != nil && valid && (lastSend.IsZero() || now.Sub(lastSend) >= sendEvery) {
				sendSeq++
				pkt := packet{
					Magic: magic, Protocol: protocol, SessionHash: sessionHash,
					PlayerID: cfg.PlayerID, Profile: prof.ID, Sequence: sendSeq,
				}
				copy(pkt.State[:], localState)
				_, _ = conn.WriteToUDP(encodePacket(pkt), peer)
				lastSend = now
			}

			if !connected && valid && !warnedNoPeer && localTick > 600 {
				fmt.Println("No peer packets received yet. Check same session_key, Radmin peer IP, and Windows Firewall UDP 37171.")
				warnedNoPeer = true
			}

			if !connected {
				continue
			}

			// Diagnostic mode intentionally stops here. It still reads and sends local state,
			// but never writes to KH1 memory, installs hooks, moves party actors, or spawns a clone.
			// This isolates multi-instance/network stability from the experimental visual layer.
			if !cfg.VisualSync {
				continue
			}

			// v0.9.5 isolation: Player 1 gets exactly one second Sora-resource actor through a nested
			// SpawnEntity call while KH1 is already inside its own native room spawn pass. The extended
			// placement table exists only for that one call and is immediately rolled back. We only READ
			// the returned actor afterward. No position, rotation, animation, visibility, cleanup, or
			// controller-state writes are performed.
			if cfg.ExistingActorOnly {
				if cfg.PlayerID == 1 && roomInject != nil {
					id, _ := roomInject.currentPuppet()
					if id != 0 {
						done, directPtr := roomInject.spawnResult(p)
						ptr := uintptr(0)
						var e error
						if done == 1 && validPointer(directPtr) {
							ptr = directPtr
						} else {
							ptr, e = findEntityByPlacementID(p, prof, id)
						}
						if e == nil && ptr != 0 {
							if nativePuppet.ptr != ptr || nativePuppet.id != id {
								nativePuppet = soraCloneState{ptr: ptr, id: id, world: localWorld, room: localRoom}
								fmt.Printf("Transient native duplicate Sora alive | entity 0x%X | id 0x%X | placement table already restored | NO POST-SPAWN WRITES\n", ptr, id)
							}
						} else if done == 1 && directPtr == 0 {
							msg := "nested SpawnEntity returned null; original placement table was restored"
							if msg != proxy.name {
								fmt.Printf("Transient duplicate result: %s\n", msg)
								proxy.name = msg
							}
						} else if e != nil && e.Error() != proxy.name {
							fmt.Printf("Native room actor waiting: %s\n", e.Error())
							proxy.name = e.Error()
						}
					}
				}
				continue
			}

			sameRoom := stateSameRoom(localState, remote.State[:])
			remoteValid := remote.State[stValid] != 0
			cutsceneBlocked := cfg.HideDuringCutscene && (localState[stCutscene] != 0 || remote.State[stCutscene] != 0)
			shouldShow := valid && remoteValid && sameRoom && !cutsceneBlocked
			if shouldShow {
				if showStableSince.IsZero() {
					showStableSince = now
					waitingForStablePrinted = false
				}
			} else {
				showStableSince = time.Time{}
				waitingForStablePrinted = false
			}
			spawnReady := shouldShow && !showStableSince.IsZero() && now.Sub(showStableSince) >= time.Duration(cfg.SpawnDelayMS)*time.Millisecond
			if shouldShow && !spawnReady && clone.ptr == 0 && !waitingForStablePrinted {
				fmt.Printf("Same room detected. Waiting %d ms for KH1 room/load state to settle before spawning the network puppet.\n", cfg.SpawnDelayMS)
				waitingForStablePrinted = true
			}

			// The frame hook is only needed for the instant in which KH1 constructs the puppet.
			// Keeping it installed for the whole session added needless crash risk in v0.4/v0.5.
			if cfg.Proxy == "auto" && spawnReady && (clone.ptr == 0 || !cloneEntityAlive(p, &clone)) &&
				gate == nil && (gateLastTry.IsZero() || now.Sub(gateLastTry) >= 2*time.Second) {
				gateLastTry = now
				g, e := installMainThreadGate(p)
				if e == nil {
					gate = g
					gateLastErr = ""
					if !gateReadyPrinted {
						fmt.Println("Second-Sora one-shot actor gate ready.")
						gateReadyPrinted = true
					}
				} else {
					msg := e.Error()
					if !strings.Contains(msg, "not ready") && msg != gateLastErr {
						fmt.Printf("Second-Sora actor gate not ready: %s\n", msg)
						gateLastErr = msg
					}
				}
			}

			cloneActive := false
			if cfg.Proxy == "auto" && shouldShow {
				if spawnReady && (clone.ptr == 0 || !cloneEntityAlive(p, &clone)) && gate != nil {
					if cloneLastTry.IsZero() || now.Sub(cloneLastTry) >= 2*time.Second {
						cloneLastTry = now
						newClone, e := spawnRemoteSoraClone(p, prof, gate, remote.State[:])
						// The gate has completed its only job. Restore KH1's original frame callback now.
						gate.uninstall(p)
						gate = nil
						if e == nil {
							clone = newClone
							clone.world = localWorld
							clone.room = localRoom
							cloneLastErr = ""
							warnedNoProxy = false
							if !cloneSpawnPrinted {
								mode := "party-registration bypass"
								if !clone.partyBypass {
									mode = fmt.Sprintf("non-party donor char 0x%X", clone.donorCharID)
								}
								fmt.Printf("Second Sora network puppet spawned | entity 0x%X | room %d:%d | %s | persistent placement | animation transitions %s\n", clone.ptr, localWorld, localRoom, mode, map[bool]string{true: "ON", false: "OFF"}[cfg.SyncAnimation])
								cloneSpawnPrinted = true
							}
							if cfg.SpawnOnly {
								fmt.Println("SPAWN-ONLY diagnostic active: clone will not be moved, animated, hidden, or cleaned up. Stay in this room for the test.")
							}
						} else {
							msg := e.Error()
							if msg != cloneLastErr {
								fmt.Printf("Second Sora spawn deferred: %s\n", msg)
								cloneLastErr = msg
							}
						}
					}
				}

				if cfg.SpawnOnly {
					// Critical diagnostic: after the constructor returns, do not write anything else into KH1.
					continue
				}

				// Applying an already-created network puppet must not depend on the one-shot gate.
				if clone.ptr != 0 && cloneEntityAlive(p, &clone) {
					if e := applyRemoteToClone(p, cfg, &clone, remote.State[:]); e == nil {
						cloneActive = true
						warnedNoProxy = false
					}
				}
			}

			if clone.ptr != 0 && (!shouldShow || !cloneActive) {
				setCloneHidden(p, &clone, true)
			}

			if cloneActive {
				continue
			}

			// Conservative fallback for rooms/builds where a second Sora cannot be constructed yet.
			active, pname, proxyErr := applyRemoteToProxy(p, prof, cfg, localState, remote.State[:])
			if proxyErr == nil && active {
				if proxy.ptr == 0 || proxy.name != pname {
					fmt.Printf("Remote visual fallback active: %s\n", pname)
				}
				proxy.name = pname
				warnedNoProxy = false
			} else if proxyErr == nil && !active {
				if sameRoom && valid && remoteValid && !warnedNoProxy {
					if cfg.Proxy == "auto" {
						fmt.Println("Peer is in the same room, but no visual actor is available yet. Second-Sora spawning will retry automatically.")
					} else {
						fmt.Println("Peer is in the same room, but the selected Donald/Goofy proxy actor does not exist here.")
					}
					warnedNoProxy = true
				}
			}
		}
	}
}

func readLocalState(p processRef, prof Profile, tick uint32) ([]byte, bool, error) {
	s := make([]byte, stateSize)
	base := p.moduleBase

	world, err := readUint8(p.handle, base+prof.World)
	if err != nil {
		return s, false, err
	}
	room, err := readUint8(p.handle, base+prof.Room)
	if err != nil {
		return s, false, err
	}
	binary.LittleEndian.PutUint16(s[stWorld:], uint16(world))
	binary.LittleEndian.PutUint16(s[stRoom:], uint16(room))

	soraRaw, err := readUint64(p.handle, base+prof.SoraPointer)
	if err != nil {
		return s, false, err
	}
	sora := uintptr(soraRaw)
	valid := validPointer(sora)
	if valid {
		s[stValid] = 1
	}

	c1, _ := readUint32(p.handle, base+prof.Cutscene)
	c2, _ := readUint32(p.handle, base+prof.InCutscene)
	if c1 != 0 || c2 != 0 {
		s[stCutscene] = 1
	}
	s[stBattle] = 0
	s[stFlags] = 0

	if valid {
		x, ex := readFloat32(p.handle, sora+0x10)
		y, ey := readFloat32(p.handle, sora+0x14)
		z, ez := readFloat32(p.handle, sora+0x18)
		if ex == nil && ey == nil && ez == nil {
			putFloat32(s[stX:], x)
			putFloat32(s[stY:], y)
			putFloat32(s[stZ:], z)
		} else {
			valid = false
			s[stValid] = 0
		}
		if a, e := readUint8(p.handle, sora+0x164); e == nil {
			binary.LittleEndian.PutUint32(s[stAnim:], uint32(a))
		}
		if a, e := readUint8(p.handle, sora+0x168); e == nil {
			binary.LittleEndian.PutUint32(s[stForceAnim:], uint32(a))
		}
		if t, e := readFloat32(p.handle, sora+0x16C); e == nil && !float32Bad(t) {
			putFloat32(s[stAnimTime:], t)
		}
		if spd, e := readFloat32(p.handle, sora+0x284); e == nil && !float32Bad(spd) {
			putFloat32(s[stAnimSpeed:], spd)
		}
		if air, e := readFloat32(p.handle, sora+0x70); e == nil && !float32Bad(air) {
			putFloat32(s[stAirborne:], air)
		}
		for _, ro := range []struct {
			state  int
			entity uintptr
		}{
			{stRotW, 0x20}, {stRotX, 0x28}, {stRotY, 0x30}, {stRotZ, 0x38},
		} {
			if v, e := readFloat32(p.handle, sora+ro.entity); e == nil && !float32Bad(v) && math.Abs(float64(v)) < 1000000 {
				putFloat32(s[ro.state:], v)
			}
		}
	}

	if hp, e := readUint8(p.handle, base+prof.SoraHP); e == nil {
		binary.LittleEndian.PutUint32(s[stHP:], uint32(hp))
	}
	if hp, e := readUint8(p.handle, base+prof.MaxHP); e == nil {
		binary.LittleEndian.PutUint32(s[stMaxHP:], uint32(hp))
	}
	if in, e := readUint32(p.handle, base+prof.InputAddress); e == nil {
		binary.LittleEndian.PutUint32(s[stInput:], in)
	}
	binary.LittleEndian.PutUint32(s[stTick:], tick)
	return s, valid, nil
}

func applyRemoteToExistingRoomActor(p processRef, prof Profile, cfg Config, remote []byte) (bool, uintptr, string, error) {
	if len(remote) < stateSize || remote[stValid] == 0 {
		return false, 0, "", nil
	}
	ptr, id, charID, err := chooseExistingRoomActor(p, prof)
	if err != nil || ptr == 0 {
		return false, 0, "", err
	}
	rx := getFloat32(remote[stX:])
	ry := getFloat32(remote[stY:])
	rz := getFloat32(remote[stZ:])
	if !finite3(rx, ry, rz) {
		return false, 0, "", nil
	}
	x, ex := readFloat32(p.handle, ptr+0x10)
	y, ey := readFloat32(p.handle, ptr+0x14)
	z, ez := readFloat32(p.handle, ptr+0x18)
	if ex != nil || ey != nil || ez != nil || !finite3(x, y, z) {
		return false, 0, "", errors.New("candidate room actor transform is not readable")
	}
	dx, dy, dz := rx-x, ry-y, rz-z
	d2 := dx*dx + dy*dy + dz*dz
	t := cfg.Smoothing
	if d2 > cfg.SnapDistance*cfg.SnapDistance {
		t = 1
	}
	if err := writeFloat32(p.handle, ptr+0x10, x+dx*t); err != nil {
		return false, 0, "", err
	}
	if err := writeFloat32(p.handle, ptr+0x14, y+dy*t); err != nil {
		return false, 0, "", err
	}
	if err := writeFloat32(p.handle, ptr+0x18, z+dz*t); err != nil {
		return false, 0, "", err
	}
	return true, ptr, fmt.Sprintf("room actor id 0x%X char 0x%X", id, charID), nil
}

func chooseExistingRoomActor(p processRef, prof Profile) (uintptr, uint32, uint16, error) {
	base := p.moduleBase
	count, err := readUint32(p.handle, base+prof.PlacementTableCount)
	if err != nil || count == 0 || count > 4096 {
		return 0, 0, 0, fmt.Errorf("placement table not ready (count %d)", count)
	}
	tableRaw, err := readUint64(p.handle, base+prof.PlacementTablePtr)
	if err != nil || !validPointer(uintptr(tableRaw)) {
		return 0, 0, 0, errors.New("placement table pointer is not ready")
	}
	table := make([]byte, int(count)*placementRecordSize)
	if err := readProcessMemory(p.handle, uintptr(tableRaw), table); err != nil {
		return 0, 0, 0, err
	}

	// Only select category-3 character placements. Props/effects may share the entity pool but
	// are not safe transform-puppet candidates.
	charByID := make(map[uint32]uint16)
	for i := 0; i < int(count); i++ {
		off := i * placementRecordSize
		id := binary.LittleEndian.Uint32(table[off+placementIDOff:])
		if byte(id>>16) != 3 {
			continue
		}
		charByID[id] = binary.LittleEndian.Uint16(table[off+placementCharIDOff:])
	}
	if len(charByID) == 0 {
		return 0, 0, 0, errors.New("no character placements exist in this room")
	}

	excludedPtrs := map[uintptr]bool{}
	excludedIDs := map[uint32]bool{}
	for _, off := range []uintptr{prof.SoraPointer, prof.SoraObjPointer, prof.DonaldPointer, prof.GoofyPointer} {
		if raw, e := readUint64(p.handle, base+off); e == nil && validPointer(uintptr(raw)) {
			ptr := uintptr(raw)
			excludedPtrs[ptr] = true
			if id, e2 := readUint32(p.handle, ptr+4); e2 == nil {
				excludedIDs[id] = true
			}
		}
	}

	poolCandidates := []uintptr{}
	if raw, e := readUint64(p.handle, base+prof.EntityPoolBase); e == nil && validPointer(uintptr(raw)) {
		poolCandidates = append(poolCandidates, uintptr(raw))
	}
	poolCandidates = append(poolCandidates, base+prof.EntityPoolBase)

	for _, pool := range poolCandidates {
		for i := 0; i < 512; i++ {
			ptr := pool + uintptr(i)*entityPoolStride
			if excludedPtrs[ptr] {
				continue
			}
			flags, e := readUint32(p.handle, ptr+entityOccFlagOff)
			if e != nil || flags&1 == 0 {
				continue
			}
			id, e := readUint32(p.handle, ptr+4)
			if e != nil || excludedIDs[id] {
				continue
			}
			charID, ok := charByID[id]
			if !ok {
				continue
			}
			x, ex := readFloat32(p.handle, ptr+0x10)
			y, ey := readFloat32(p.handle, ptr+0x14)
			z, ez := readFloat32(p.handle, ptr+0x18)
			if ex != nil || ey != nil || ez != nil || !finite3(x, y, z) {
				continue
			}
			return ptr, id, charID, nil
		}
	}
	return 0, 0, 0, errors.New("no safe existing non-player character actor is active in this room")
}

func displayPartyName(member string) string {
	if member == "goofy" {
		return "Goofy"
	}
	return "Donald"
}

func signedRel32(b []byte) int64 {
	return int64(int32(binary.LittleEndian.Uint32(b)))
}

// findRoomPlacementSpawnPatch locates the small block immediately before KH1 iterates the
// placement table. It verifies both RIP-relative placement globals and the later SpawnEntity call,
// so the same code works across supported Epic/Steam revisions without hard-coded hook RVAs.
func findRoomPlacementSpawnPatch(p processRef, prof Profile) (patchAddr, resumeAddr, skipAddr uintptr, original []byte, err error) {
	const textStart = uintptr(0x1000)
	const textSize = 0x3B0000
	buf := make([]byte, textSize)
	if e := readProcessMemory(p.handle, p.moduleBase+textStart, buf); e != nil {
		return 0, 0, 0, nil, e
	}
	countTarget := p.moduleBase + prof.PlacementTableCount
	ptrTarget := p.moduleBase + prof.PlacementTablePtr
	spawnTarget := p.moduleBase + prof.SpawnEntity
	for i := 0; i+0x70 < len(buf); i++ {
		// xor edi,edi ; cmp dword ptr [rip+disp32],edi ; jle rel8 ;
		// mov [rsp+30h],rbx ; mov rbx,[rip+disp32] ; add rbx,4
		if buf[i] != 0x33 || buf[i+1] != 0xFF ||
			buf[i+2] != 0x39 || buf[i+3] != 0x3D ||
			buf[i+8] != 0x7E ||
			buf[i+10] != 0x48 || buf[i+11] != 0x89 || buf[i+12] != 0x5C || buf[i+13] != 0x24 || buf[i+14] != 0x30 ||
			buf[i+15] != 0x48 || buf[i+16] != 0x8B || buf[i+17] != 0x1D ||
			buf[i+22] != 0x48 || buf[i+23] != 0x83 || buf[i+24] != 0xC3 || buf[i+25] != 0x04 {
			continue
		}
		baseInstr := p.moduleBase + textStart + uintptr(i)
		cmpAddr := baseInstr + 2
		cmpTarget := uintptr(int64(cmpAddr+6) + signedRel32(buf[i+4:i+8]))
		movAddr := baseInstr + 15
		movTarget := uintptr(int64(movAddr+7) + signedRel32(buf[i+18:i+22]))
		if cmpTarget != countTarget || movTarget != ptrTarget {
			continue
		}
		foundSpawn := false
		for j := i + 26; j+5 <= i+0x70 && j+5 <= len(buf); j++ {
			if buf[j] != 0xE8 {
				continue
			}
			callAddr := p.moduleBase + textStart + uintptr(j)
			target := uintptr(int64(callAddr+5) + signedRel32(buf[j+1:j+5]))
			if target == spawnTarget {
				foundSpawn = true
				break
			}
		}
		if !foundSpawn {
			continue
		}
		rel8 := int8(buf[i+9])
		skip := uintptr(int64(baseInstr+10) + int64(rel8))
		orig := append([]byte(nil), buf[i:i+15]...)
		return baseInstr, baseInstr + 15, skip, orig, nil
	}
	return 0, 0, 0, nil, errors.New("native placement spawn-loop signature not found")
}

// findRoomSpawnDuplicatePatch locates the exact per-placement SpawnEntity call inside the room
// loop found above. We replace the 14-byte block
//
//	mov ecx,[rbx-4] ; call SpawnEntity ; add rbx,78h ; inc edi
//
// with an absolute jump to a cave that replays those instructions and, for Sora's placement only,
// performs one extra transient SpawnEntity call.
func findRoomSpawnDuplicatePatch(p processRef, prof Profile, loopStart uintptr) (patchAddr, resumeAddr uintptr, original []byte, err error) {
	buf := make([]byte, 0x90)
	if e := readProcessMemory(p.handle, loopStart, buf); e != nil {
		return 0, 0, nil, e
	}
	spawnTarget := p.moduleBase + prof.SpawnEntity
	for i := 0; i+14 <= len(buf); i++ {
		if buf[i] != 0x8B || buf[i+1] != 0x4B || buf[i+2] != 0xFC ||
			buf[i+3] != 0xE8 ||
			buf[i+8] != 0x48 || buf[i+9] != 0x83 || buf[i+10] != 0xC3 || buf[i+11] != 0x78 ||
			buf[i+12] != 0xFF || buf[i+13] != 0xC7 {
			continue
		}
		callAddr := loopStart + uintptr(i+3)
		target := uintptr(int64(callAddr+5) + signedRel32(buf[i+4:i+8]))
		if target != spawnTarget {
			continue
		}
		start := loopStart + uintptr(i)
		orig := append([]byte(nil), buf[i:i+14]...)
		return start, start + 14, orig, nil
	}
	return 0, 0, nil, errors.New("native room SpawnEntity call block not found")
}

func buildRoomSpawnDuplicateCave(controlAddr, tablePtrAddr, countAddr, spawnTarget, resumeAddr uintptr) []byte {
	code := make([]byte, 0, 256)
	add := func(v ...byte) { code = append(code, v...) }
	u32 := func(v uint32) {
		b := make([]byte, 4)
		binary.LittleEndian.PutUint32(b, v)
		code = append(code, b...)
	}
	u64 := func(v uint64) {
		b := make([]byte, 8)
		binary.LittleEndian.PutUint64(b, v)
		code = append(code, b...)
	}
	absCall := func(target uintptr) {
		add(0x48, 0xB8) // mov rax,imm64
		u64(uint64(target))
		add(0xFF, 0xD0) // call rax
	}
	absJmp := func(target uintptr) {
		add(0xFF, 0x25, 0, 0, 0, 0)
		u64(uint64(target))
	}
	patchRel32 := func(pos int, target int) {
		rel := int32(target - (pos + 6))
		binary.LittleEndian.PutUint32(code[pos+2:pos+6], uint32(rel))
	}

	// Replay KH1's real spawn call first. This is the original room-loop behavior.
	add(0x8B, 0x4B, 0xFC) // mov ecx,[rbx-4]
	absCall(spawnTarget)

	// Only duplicate the source Sora placement, and only once.
	add(0x49, 0xBA)
	u64(uint64(controlAddr))          // mov r10,control
	add(0x41, 0x83, 0x7A, 0x30, 0x00) // cmp dword [r10+30h],0
	jneDone := len(code)
	add(0x0F, 0x85, 0, 0, 0, 0) // jne done
	add(0x41, 0x8B, 0x42, 0x08) // mov eax,[r10+8] sourceID
	add(0x39, 0x43, 0xFC)       // cmp [rbx-4],eax
	jneSource := len(code)
	add(0x0F, 0x85, 0, 0, 0, 0) // jne done
	add(0x4D, 0x8B, 0x5A, 0x10) // mov r11,[r10+10h] tempTable
	add(0x4D, 0x85, 0xDB)       // test r11,r11
	jzTable := len(code)
	add(0x0F, 0x84, 0, 0, 0, 0) // jz done

	// Swap the placement globals only for the nested call.
	add(0x48, 0xB8)
	u64(uint64(tablePtrAddr))   // mov rax,&placementTablePtr
	add(0x4C, 0x89, 0x18)       // mov [rax],r11
	add(0x45, 0x8B, 0x5A, 0x24) // mov r11d,[r10+24h] newCount
	add(0x48, 0xB8)
	u64(uint64(countAddr))      // mov rax,&placementCount
	add(0x44, 0x89, 0x18)       // mov [rax],r11d
	add(0x41, 0x8B, 0x4A, 0x0C) // mov ecx,[r10+0Ch] newID
	absCall(spawnTarget)

	// SpawnEntity may clobber volatile r10/r11, so reload control before rollback.
	add(0x49, 0xBA)
	u64(uint64(controlAddr))
	add(0x49, 0x89, 0x42, 0x28) // mov [r10+28h],rax puppetPtr
	add(0x4D, 0x8B, 0x5A, 0x18) // mov r11,[r10+18h] originalTable
	add(0x48, 0xB8)
	u64(uint64(tablePtrAddr))
	add(0x4C, 0x89, 0x18)       // mov [rax],r11
	add(0x45, 0x8B, 0x5A, 0x20) // mov r11d,[r10+20h] originalCount
	add(0x48, 0xB8)
	u64(uint64(countAddr))
	add(0x44, 0x89, 0x18) // mov [rax],r11d
	add(0x41, 0xC7, 0x42, 0x30)
	u32(1) // mov dword [r10+30h],1

	donePos := len(code)
	patchRel32(jneDone, donePos)
	patchRel32(jneSource, donePos)
	patchRel32(jzTable, donePos)

	// Replay the rest of the displaced room-loop block.
	add(0x48, 0x83, 0xC3, 0x78) // add rbx,78h
	add(0xFF, 0xC7)             // inc edi
	absJmp(resumeAddr)
	return code
}

func buildRoomPartyInjectionCave(controlAddr, countAddr, resumeAddr, skipAddr uintptr) []byte {
	code := make([]byte, 0, 128)
	add := func(v ...byte) { code = append(code, v...) }
	u32 := func(v uint32) { b := make([]byte, 4); binary.LittleEndian.PutUint32(b, v); code = append(code, b...) }
	u64 := func(v uint64) { b := make([]byte, 8); binary.LittleEndian.PutUint64(b, v); code = append(code, b...) }

	// request=1; bounded spin until bridge sets ready=1. r10/r11 are volatile here.
	add(0x49, 0xBA)
	u64(uint64(controlAddr)) // mov r10,control
	add(0x41, 0xC7, 0x02)
	u32(1) // mov dword [r10],1
	add(0x41, 0xBB)
	u32(0x18000000) // mov r11d,spin count
	waitPos := len(code)
	add(0xF3, 0x90)                   // pause
	add(0x41, 0x83, 0x7A, 0x04, 0x01) // cmp dword [r10+4],1
	readyJcc := len(code)
	add(0x74, 0x00)       // je ready
	add(0x41, 0xFF, 0xCB) // dec r11d
	loopJcc := len(code)
	add(0x75, 0x00) // jne wait
	readyPos := len(code)
	code[readyJcc+1] = byte(int8(readyPos - (readyJcc + 2)))
	code[loopJcc+1] = byte(int8(waitPos - (loopJcc + 2)))
	add(0x41, 0xC7, 0x02)
	u32(0) // request=0
	add(0x41, 0xC7, 0x42, 0x04)
	u32(0) // ready=0

	// Re-create the 15 displaced bytes semantically, using absolute count address.
	add(0x33, 0xFF) // xor edi,edi
	add(0x48, 0xB8)
	u64(uint64(countAddr)) // mov rax,count
	add(0x39, 0x38)        // cmp [rax],edi
	jlePos := len(code)
	add(0x7E, 0x00)                   // jle skip
	add(0x48, 0x89, 0x5C, 0x24, 0x30) // mov [rsp+30],rbx
	add(0x48, 0xB8)
	u64(uint64(resumeAddr)) // mov rax,resume
	add(0xFF, 0xE0)         // jmp rax
	skipPos := len(code)
	code[jlePos+1] = byte(int8(skipPos - (jlePos + 2)))
	add(0x48, 0xB8)
	u64(uint64(skipAddr)) // mov rax,skip
	add(0xFF, 0xE0)       // jmp rax
	return code
}

func findPartyRegistrationSequence(p processRef, spawnAddr uintptr) (uintptr, uintptr, uintptr, []byte, error) {
	const scanSize = 0x900
	buf := make([]byte, scanSize)
	if err := readProcessMemory(p.handle, spawnAddr, buf); err != nil {
		return 0, 0, 0, nil, err
	}
	for i := 0; i+19 <= len(buf); i++ {
		// cmp eax,2 ; ja rel32 ; cmp byte ptr [rdi+6],3 ; jne rel32
		if buf[i] != 0x83 || buf[i+1] != 0xF8 || buf[i+2] != 0x02 ||
			buf[i+3] != 0x0F || buf[i+4] != 0x87 ||
			buf[i+9] != 0x80 || buf[i+10] != 0x7F || buf[i+11] != 0x06 || buf[i+12] != 0x03 ||
			buf[i+13] != 0x0F || buf[i+14] != 0x85 {
			continue
		}
		start := spawnAddr + uintptr(i)
		jaAddr := spawnAddr + uintptr(i+3)
		rel := int32(binary.LittleEndian.Uint32(buf[i+5 : i+9]))
		skip := uintptr(int64(jaAddr) + 6 + int64(rel))
		resume := spawnAddr + uintptr(i+19)
		orig := append([]byte(nil), buf[i:i+19]...)
		return start, resume, skip, orig, nil
	}
	return 0, 0, 0, nil, errors.New("party-registration sequence signature not found")
}

func buildConditionalPartyBypassCave(resumeAddr, skipAddr uintptr) ([]byte, int) {
	code := make([]byte, 0, 96)
	add := func(v ...byte) { code = append(code, v...) }
	u32 := func(v uint32) {
		b := make([]byte, 4)
		binary.LittleEndian.PutUint32(b, v)
		code = append(code, b...)
	}
	u64 := func(v uint64) {
		b := make([]byte, 8)
		binary.LittleEndian.PutUint64(b, v)
		code = append(code, b...)
	}
	absJmp := func(target uintptr) {
		add(0xFF, 0x25, 0, 0, 0, 0)
		u64(uint64(target))
	}

	// Only the injected placement ID bypasses the player/party registration block.
	// Every real Sora/Donald/Goofy actor still executes KH1's original logic.
	add(0x81, 0x7F, 0x04) // cmp dword ptr [rdi+4], imm32
	idOffset := len(code)
	u32(0)
	jePos := len(code)
	add(0x0F, 0x84, 0, 0, 0, 0) // je skip
	add(0x83, 0xF8, 0x02)       // cmp eax,2
	jaPos := len(code)
	add(0x0F, 0x87, 0, 0, 0, 0) // ja skip
	add(0x80, 0x7F, 0x06, 0x03) // cmp byte ptr [rdi+6],3
	jnePos := len(code)
	add(0x0F, 0x85, 0, 0, 0, 0) // jne skip
	absJmp(resumeAddr)
	skipPos := len(code)
	absJmp(skipAddr)
	for _, pos := range []int{jePos, jaPos, jnePos} {
		rel := int32(skipPos - (pos + 6))
		binary.LittleEndian.PutUint32(code[pos+2:pos+6], uint32(rel))
	}
	return code, idOffset
}

func installConditionalPartyBypass(p processRef, prof Profile) (*conditionalPartyBypass, error) {
	patchAddr, resumeAddr, skipAddr, original, err := findPartyRegistrationSequence(p, p.moduleBase+prof.SpawnEntity)
	if err != nil {
		return nil, err
	}
	codeAddr, err := virtualAllocEx(p.handle, 0x100, pageExecuteReadWrite)
	if err != nil {
		return nil, err
	}
	cave, idOff := buildConditionalPartyBypassCave(resumeAddr, skipAddr)
	if err := writeProcessMemory(p.handle, codeAddr, cave); err != nil {
		return nil, err
	}
	procFlushInstructionCache.Call(uintptr(p.handle), codeAddr, uintptr(len(cave)))

	patch := make([]byte, 19)
	patch[0] = 0xFF
	patch[1] = 0x25 // jmp qword ptr [rip+0]
	binary.LittleEndian.PutUint32(patch[2:6], 0)
	binary.LittleEndian.PutUint64(patch[6:14], uint64(codeAddr))
	for i := 14; i < len(patch); i++ {
		patch[i] = 0x90
	}
	if err := protectedWriteBytes(p.handle, patchAddr, patch); err != nil {
		return nil, err
	}
	return &conditionalPartyBypass{patchAddr: patchAddr, codeAddr: codeAddr, idAddr: codeAddr + uintptr(idOff), original: original}, nil
}

func (b *conditionalPartyBypass) setPuppetID(p processRef, id uint32) error {
	if b == nil || b.idAddr == 0 {
		return errors.New("conditional party bypass unavailable")
	}
	if err := writeUint32(p.handle, b.idAddr, id); err != nil {
		return err
	}
	procFlushInstructionCache.Call(uintptr(p.handle), b.codeAddr, uintptr(0x80))
	return nil
}

func (b *conditionalPartyBypass) uninstall(p processRef) {
	if b == nil || b.patchAddr == 0 || len(b.original) == 0 {
		return
	}
	_ = protectedWriteBytes(p.handle, b.patchAddr, b.original)
}

func installRoomPartyInjectionHook(p processRef, prof Profile) (*roomPartyInjectionHook, error) {
	patchAddr, resumeAddr, skipAddr, original, err := findRoomPlacementSpawnPatch(p, prof)
	if err != nil {
		return nil, err
	}
	spawnPatchAddr, spawnResumeAddr, spawnOriginal, err := findRoomSpawnDuplicatePatch(p, prof, patchAddr)
	if err != nil {
		return nil, err
	}
	control, err := virtualAllocEx(p.handle, 0x80, pageReadWrite)
	if err != nil {
		return nil, err
	}
	code, err := virtualAllocEx(p.handle, 0x200, pageExecuteReadWrite)
	if err != nil {
		return nil, err
	}
	spawnCode, err := virtualAllocEx(p.handle, 0x300, pageExecuteReadWrite)
	if err != nil {
		return nil, err
	}
	cave := buildRoomPartyInjectionCave(control, p.moduleBase+prof.PlacementTableCount, resumeAddr, skipAddr)
	if err := writeProcessMemory(p.handle, code, cave); err != nil {
		return nil, err
	}
	procFlushInstructionCache.Call(uintptr(p.handle), code, uintptr(len(cave)))
	spawnCave := buildRoomSpawnDuplicateCave(
		control,
		p.moduleBase+prof.PlacementTablePtr,
		p.moduleBase+prof.PlacementTableCount,
		p.moduleBase+prof.SpawnEntity,
		spawnResumeAddr,
	)
	if err := writeProcessMemory(p.handle, spawnCode, spawnCave); err != nil {
		return nil, err
	}
	procFlushInstructionCache.Call(uintptr(p.handle), spawnCode, uintptr(len(spawnCave)))
	patch := make([]byte, 15)
	patch[0] = 0xFF
	patch[1] = 0x25 // jmp qword ptr [rip+0]
	binary.LittleEndian.PutUint32(patch[2:6], 0)
	binary.LittleEndian.PutUint64(patch[6:14], uint64(code))
	patch[14] = 0x90
	if err := protectedWriteBytes(p.handle, patchAddr, patch); err != nil {
		return nil, err
	}
	spawnPatch := make([]byte, 14)
	spawnPatch[0] = 0xFF
	spawnPatch[1] = 0x25 // jmp qword ptr [rip+0]
	binary.LittleEndian.PutUint32(spawnPatch[2:6], 0)
	binary.LittleEndian.PutUint64(spawnPatch[6:14], uint64(spawnCode))
	if err := protectedWriteBytes(p.handle, spawnPatchAddr, spawnPatch); err != nil {
		_ = protectedWriteBytes(p.handle, patchAddr, original)
		return nil, err
	}
	h := &roomPartyInjectionHook{
		patchAddr:       patchAddr,
		resumeAddr:      resumeAddr,
		skipAddr:        skipAddr,
		codeAddr:        code,
		spawnPatchAddr:  spawnPatchAddr,
		spawnResumeAddr: spawnResumeAddr,
		spawnCodeAddr:   spawnCode,
		controlAddr:     control,
		original:        original,
		spawnOriginal:   spawnOriginal,
		stop:            make(chan struct{}),
		done:            make(chan struct{}),
	}
	go h.worker(p, prof)
	return h, nil
}

func (h *roomPartyInjectionHook) currentPuppet() (uint32, time.Time) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.puppetID, h.injectedAt
}

func (h *roomPartyInjectionHook) spawnResult(p processRef) (uint32, uintptr) {
	if h == nil || h.controlAddr == 0 {
		return 0, 0
	}
	done, _ := readUint32(p.handle, h.controlAddr+0x30)
	ptr, _ := readUint64(p.handle, h.controlAddr+0x28)
	return done, uintptr(ptr)
}

func (h *roomPartyInjectionHook) rememberInjection(original uintptr, originalCount uint32, injected uintptr, puppetID uint32) {
	h.mu.Lock()
	h.originalTable = original
	h.originalCount = originalCount
	h.injectedTable = injected
	h.puppetID = puppetID
	h.injectedAt = time.Now()
	h.mu.Unlock()
}

func (h *roomPartyInjectionHook) worker(p processRef, prof Profile) {
	defer close(h.done)
	ticker := time.NewTicker(time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-h.stop:
			return
		case <-ticker.C:
			req, e := readUint32(p.handle, h.controlAddr)
			if e != nil || req != 1 {
				continue
			}
			origTable, _ := readUint64(p.handle, p.moduleBase+prof.PlacementTablePtr)
			count, _ := readUint32(p.handle, p.moduleBase+prof.PlacementTableCount)
			if validPointer(uintptr(origTable)) && count > 0 && count < 4096 {
				h.mu.RLock()
				already := h.puppetID != 0
				h.mu.RUnlock()
				if !already {
					if newTable, newCount, sourceChar, sourceID, puppetID, e2 := prepareTransientDonaldSlotSoraPlacement(p, uintptr(origTable), count); e2 == nil {
						// Control block consumed by the room SpawnEntity-call cave.
						_ = writeUint32(p.handle, h.controlAddr+0x08, sourceID)
						_ = writeUint32(p.handle, h.controlAddr+0x0C, puppetID)
						_ = writeUint64(p.handle, h.controlAddr+0x10, uint64(newTable))
						_ = writeUint64(p.handle, h.controlAddr+0x18, origTable)
						_ = writeUint32(p.handle, h.controlAddr+0x20, count)
						_ = writeUint32(p.handle, h.controlAddr+0x24, newCount)
						_ = writeUint64(p.handle, h.controlAddr+0x28, 0)
						_ = writeUint32(p.handle, h.controlAddr+0x30, 0)
						h.rememberInjection(uintptr(origTable), count, newTable, puppetID)
						fmt.Printf("Transient room splice prepared: Sora resources -> Donald slot | source id 0x%X | duplicate id 0x%X | source char %d -> 1 | placements %d -> %d | original table remains active.\n", sourceID, puppetID, sourceChar, count, newCount)
					} else {
						fmt.Printf("Transient room splice preparation skipped: %s\n", e2.Error())
					}
				}
			}
			_ = writeUint32(p.handle, h.controlAddr+4, 1)
		}
	}
}

// chooseNeutralPartySafeCharID reads KH1's own four-character party-registration table and
// chooses a valid low character ID that is not currently registered in any player/party slot.
// SpawnEntity naturally returns -1 for that ID and skips its local player/party registration block,
// so no code patch inside the constructor is necessary.
func chooseNeutralPartySafeCharID(p processRef, prof Profile) (uint16, []byte, error) {
	const scanSize = 0x900
	buf := make([]byte, scanSize)
	spawnAddr := p.moduleBase + prof.SpawnEntity
	if err := readProcessMemory(p.handle, spawnAddr, buf); err != nil {
		return 0, nil, err
	}
	var mapFn uintptr
	for i := 8; i+19 <= len(buf); i++ {
		if buf[i] != 0x83 || buf[i+1] != 0xF8 || buf[i+2] != 0x02 || buf[i+3] != 0x0F || buf[i+4] != 0x87 {
			continue
		}
		lo := i - 48
		if lo < 0 {
			lo = 0
		}
		for j := i - 5; j >= lo; j-- {
			if j+9 <= len(buf) && buf[j] == 0x0F && buf[j+1] == 0xB7 && buf[j+2] == 0x48 && buf[j+3] == 0x4C && buf[j+4] == 0xE8 {
				callAddr := spawnAddr + uintptr(j+4)
				mapFn = uintptr(int64(callAddr+5) + signedRel32(buf[j+5:j+9]))
				break
			}
		}
		if mapFn != 0 {
			break
		}
	}
	if mapFn == 0 {
		return 0, nil, errors.New("party-index mapper call not found")
	}
	head := make([]byte, 7)
	if err := readProcessMemory(p.handle, mapFn, head); err != nil {
		return 0, nil, err
	}
	if head[0] != 0x4C || head[1] != 0x8B || head[2] != 0x0D {
		return 0, nil, errors.New("party-index mapper global signature changed")
	}
	globalPtrAddr := uintptr(int64(mapFn+7) + signedRel32(head[3:7]))
	gameDataRaw, err := readUint64(p.handle, globalPtrAddr)
	if err != nil || !validPointer(uintptr(gameDataRaw)) {
		return 0, nil, errors.New("party-index game-data pointer unavailable")
	}
	partyIDs := make([]byte, 4)
	if err := readProcessMemory(p.handle, uintptr(gameDataRaw)+0x48E, partyIDs); err != nil {
		return 0, nil, err
	}
	used := map[byte]bool{}
	for _, id := range partyIDs {
		used[id] = true
	}
	// IDs 3..9 are KH1's low character/guest range and pass the same general character setup
	// as party actors, but an ID not present in the current four-slot table is not registered locally.
	for _, candidate := range []byte{9, 8, 7, 6, 5, 4, 3} {
		if !used[candidate] {
			return uint16(candidate), partyIDs, nil
		}
	}
	return 0, partyIDs, errors.New("all neutral low character IDs are currently reserved")
}

func prepareTransientDonaldSlotSoraPlacement(p processRef, tablePtr uintptr, count uint32) (uintptr, uint32, uint16, uint32, uint32, error) {
	if count == 0 || count >= 4096 {
		return 0, count, 0, 0, 0, fmt.Errorf("placement count invalid: %d", count)
	}
	table := make([]byte, int(count)*placementRecordSize)
	if err := readProcessMemory(p.handle, tablePtr, table); err != nil {
		return 0, count, 0, 0, 0, err
	}

	source := -1
	var sourceChar uint16
	var sourceID uint32
	for i := 0; i < int(count); i++ {
		off := i * placementRecordSize
		id := binary.LittleEndian.Uint32(table[off+placementIDOff:])
		ch := binary.LittleEndian.Uint16(table[off+placementCharIDOff:])
		if byte(id>>16) == 3 && ch == 0 {
			source = off
			sourceChar = ch
			sourceID = id
			break
		}
	}
	if source < 0 {
		return 0, count, 0, 0, 0, errors.New("Sora placement record was not present before the room spawn pass")
	}

	newCount := count + 1
	newSize := uintptr(newCount) * placementRecordSize
	newTable, err := virtualAllocEx(p.handle, newSize, pageReadWrite)
	if err != nil {
		return 0, count, sourceChar, sourceID, 0, fmt.Errorf("allocate transient placement table: %w", err)
	}
	if err := writeProcessMemory(p.handle, newTable, table); err != nil {
		return 0, count, sourceChar, sourceID, 0, fmt.Errorf("copy transient placement table: %w", err)
	}

	rec := make([]byte, placementRecordSize)
	copy(rec, table[source:source+placementRecordSize])
	newID := uint32(3<<16) | (count & 0xFFFF)
	binary.LittleEndian.PutUint32(rec[placementIDOff:], newID)
	// Keep the only resource/party combination that has successfully reached gameplay so far:
	// Sora model/motion/resource handles, registered in Donald's character slot for the duplicate.
	binary.LittleEndian.PutUint16(rec[placementCharIDOff:], 1)
	x := getFloat32(rec[placementPosXOff:])
	putFloat32(rec[placementPosXOff:], x+140.0)
	if err := writeProcessMemory(p.handle, newTable+uintptr(count)*placementRecordSize, rec); err != nil {
		return 0, count, sourceChar, sourceID, 0, fmt.Errorf("write transient duplicate placement: %w", err)
	}

	return newTable, newCount, sourceChar, sourceID, newID, nil
}

func findEntityByPlacementID(p processRef, prof Profile, id uint32) (uintptr, error) {
	if id == 0 {
		return 0, errors.New("neutral Sora placement ID is not armed yet")
	}
	base := p.moduleBase
	poolCandidates := []uintptr{}
	if raw, e := readUint64(p.handle, base+prof.EntityPoolBase); e == nil && validPointer(uintptr(raw)) {
		poolCandidates = append(poolCandidates, uintptr(raw))
	}
	poolCandidates = append(poolCandidates, base+prof.EntityPoolBase)
	for _, pool := range poolCandidates {
		for i := 0; i < 128; i++ {
			ptr := pool + uintptr(i)*entityPoolStride
			flags, e := readUint32(p.handle, ptr+entityOccFlagOff)
			if e != nil || flags&1 == 0 {
				continue
			}
			entityID, e := readUint32(p.handle, ptr+4)
			if e == nil && entityID == id {
				return ptr, nil
			}
		}
	}
	return 0, fmt.Errorf("neutral Sora entity 0x%X has not materialized yet", id)
}

func (h *roomPartyInjectionHook) uninstall(p processRef) {
	select {
	case <-h.stop:
	default:
		close(h.stop)
	}
	select {
	case <-h.done:
	case <-time.After(100 * time.Millisecond):
	}
	if h.spawnPatchAddr != 0 && len(h.spawnOriginal) != 0 {
		_ = protectedWriteBytes(p.handle, h.spawnPatchAddr, h.spawnOriginal)
	}
	if h.patchAddr != 0 && len(h.original) != 0 {
		_ = protectedWriteBytes(p.handle, h.patchAddr, h.original)
	}
}

func forceReservedPartyMember(p processRef, prof Profile, member string) (bool, error) {
	// KH1 party IDs used by the PC randomizer/speedrun tooling: 1 = Donald, 2 = Goofy,
	// 0xFF = empty. Keep slot 0 reserved and leave slot 1 alone so a world guest can remain.
	var id byte = 1
	if member == "goofy" {
		id = 2
	}
	changed := false
	for _, off := range []uintptr{prof.PartyConfig, prof.PartyRuntime} {
		if off == 0 {
			continue
		}
		addr := p.moduleBase + off
		cur, err := readUint8(p.handle, addr)
		if err != nil {
			return changed, err
		}
		if cur != id {
			if err := writeUint8(p.handle, addr, id); err != nil {
				return changed, err
			}
			changed = true
		}
	}
	return changed, nil
}

func chooseReservedPartyProxy(p processRef, prof Profile, member string) (uintptr, string, error) {
	// Party slot 0 is the first pointer; slot 1 is the second. Because forceReservedPartyMember
	// reserves slot 0, that pointer should be the requested Donald/Goofy actor once KH1 refreshes.
	raw, err := readUint64(p.handle, p.moduleBase+prof.DonaldPointer)
	if err != nil {
		return 0, "", err
	}
	ptr := uintptr(raw)
	if !validPointer(ptr) {
		return 0, displayPartyName(member), nil
	}
	return ptr, displayPartyName(member), nil
}

func applyRemoteToReservedParty(p processRef, prof Profile, cfg Config, member string, remote []byte) (bool, uintptr, string, error) {
	if len(remote) < stateSize || remote[stValid] == 0 {
		return false, 0, "", nil
	}
	ptr, name, err := chooseReservedPartyProxy(p, prof, member)
	if err != nil {
		return false, 0, "", err
	}
	if ptr == 0 {
		return false, 0, name, fmt.Errorf("%s party actor has not materialized yet", name)
	}
	flags, err := readUint32(p.handle, ptr+entityOccFlagOff)
	if err != nil || flags&1 == 0 {
		return false, 0, name, fmt.Errorf("%s party actor is not active yet", name)
	}
	rx := getFloat32(remote[stX:])
	ry := getFloat32(remote[stY:])
	rz := getFloat32(remote[stZ:])
	if !finite3(rx, ry, rz) {
		return false, 0, name, nil
	}
	x, ex := readFloat32(p.handle, ptr+0x10)
	y, ey := readFloat32(p.handle, ptr+0x14)
	z, ez := readFloat32(p.handle, ptr+0x18)
	if ex != nil || ey != nil || ez != nil || !finite3(x, y, z) {
		return false, 0, name, errors.New("reserved party actor transform is not readable")
	}
	dx, dy, dz := rx-x, ry-y, rz-z
	d2 := dx*dx + dy*dy + dz*dz
	t := cfg.Smoothing
	if d2 > cfg.SnapDistance*cfg.SnapDistance {
		t = 1
	}
	if err := writeFloat32(p.handle, ptr+0x10, x+dx*t); err != nil {
		return false, 0, name, err
	}
	if err := writeFloat32(p.handle, ptr+0x14, y+dy*t); err != nil {
		return false, 0, name, err
	}
	if err := writeFloat32(p.handle, ptr+0x18, z+dz*t); err != nil {
		return false, 0, name, err
	}
	return true, ptr, name, nil
}

func applyRemotePositionOnly(p processRef, cfg Config, ptr uintptr, remote []byte) error {
	if ptr == 0 || len(remote) < stateSize || remote[stValid] == 0 {
		return nil
	}
	rx := getFloat32(remote[stX:])
	ry := getFloat32(remote[stY:])
	rz := getFloat32(remote[stZ:])
	if !finite3(rx, ry, rz) {
		return nil
	}
	x, ex := readFloat32(p.handle, ptr+0x10)
	y, ey := readFloat32(p.handle, ptr+0x14)
	z, ez := readFloat32(p.handle, ptr+0x18)
	if ex != nil || ey != nil || ez != nil || !finite3(x, y, z) {
		return errors.New("neutral Sora transform is not readable")
	}
	dx, dy, dz := rx-x, ry-y, rz-z
	d2 := dx*dx + dy*dy + dz*dz
	t := cfg.Smoothing
	if d2 > cfg.SnapDistance*cfg.SnapDistance {
		t = 1
	}
	if err := writeFloat32(p.handle, ptr+0x10, x+dx*t); err != nil {
		return err
	}
	if err := writeFloat32(p.handle, ptr+0x14, y+dy*t); err != nil {
		return err
	}
	if err := writeFloat32(p.handle, ptr+0x18, z+dz*t); err != nil {
		return err
	}
	return nil
}

func applyRemoteToProxy(p processRef, prof Profile, cfg Config, local, remote []byte) (bool, string, error) {
	if len(local) < stateSize || len(remote) < stateSize || local[stValid] == 0 || remote[stValid] == 0 {
		return false, "", nil
	}
	if !stateSameRoom(local, remote) {
		return false, "", nil
	}
	if cfg.HideDuringCutscene && (local[stCutscene] != 0 || remote[stCutscene] != 0) {
		return false, "", nil
	}

	ptr, name, err := chooseProxy(p, prof, cfg.Proxy)
	if err != nil || ptr == 0 {
		return false, "", err
	}

	rx := getFloat32(remote[stX:])
	ry := getFloat32(remote[stY:])
	rz := getFloat32(remote[stZ:])
	if !finite3(rx, ry, rz) {
		return false, "", nil
	}

	x, err := readFloat32(p.handle, ptr+0x10)
	if err != nil {
		return false, "", err
	}
	y, err := readFloat32(p.handle, ptr+0x14)
	if err != nil {
		return false, "", err
	}
	z, err := readFloat32(p.handle, ptr+0x18)
	if err != nil {
		return false, "", err
	}

	dx, dy, dz := rx-x, ry-y, rz-z
	d2 := dx*dx + dy*dy + dz*dz
	t := cfg.Smoothing
	if d2 > cfg.SnapDistance*cfg.SnapDistance {
		t = 1.0
	}

	if err := writeFloat32(p.handle, ptr+0x10, x+dx*t); err != nil {
		return false, "", err
	}
	if err := writeFloat32(p.handle, ptr+0x14, y+dy*t); err != nil {
		return false, "", err
	}
	if err := writeFloat32(p.handle, ptr+0x18, z+dz*t); err != nil {
		return false, "", err
	}
	return true, name, nil
}

func stateSameRoom(a, b []byte) bool {
	if len(a) < stateSize || len(b) < stateSize {
		return false
	}
	return binary.LittleEndian.Uint16(a[stWorld:]) == binary.LittleEndian.Uint16(b[stWorld:]) &&
		binary.LittleEndian.Uint16(a[stRoom:]) == binary.LittleEndian.Uint16(b[stRoom:])
}

func chooseProxy(p processRef, prof Profile, mode string) (uintptr, string, error) {
	readPtr := func(off uintptr) (uintptr, error) {
		v, err := readUint64(p.handle, p.moduleBase+off)
		if err != nil {
			return 0, err
		}
		ptr := uintptr(v)
		if !validPointer(ptr) {
			return 0, nil
		}
		return ptr, nil
	}

	if mode == "donald" {
		ptr, err := readPtr(prof.DonaldPointer)
		return ptr, "Donald", err
	}
	if mode == "goofy" {
		ptr, err := readPtr(prof.GoofyPointer)
		return ptr, "Goofy", err
	}
	if ptr, err := readPtr(prof.GoofyPointer); err == nil && ptr != 0 {
		return ptr, "Goofy", nil
	}
	ptr, err := readPtr(prof.DonaldPointer)
	return ptr, "Donald", err
}

func installMainThreadGate(p processRef) (*mainThreadGate, error) {
	textAddr, textSize, err := remoteTextSection(p)
	if err != nil {
		return nil, err
	}
	if textSize == 0 || textSize > 0x800000 {
		return nil, fmt.Errorf("unexpected .text size 0x%X", textSize)
	}
	text := make([]byte, textSize)
	if err := readProcessMemory(p.handle, textAddr, text); err != nil {
		return nil, fmt.Errorf("read .text: %w", err)
	}

	// Same stable app-pointer signature used by LuaBackend's hook build.
	pattern := []byte{0x48, 0x89, 0x35, 0, 0, 0, 0, 0x48, 0x8B, 0xC6}
	match := -1
	for i := 0; i+len(pattern) <= len(text); i++ {
		if text[i] == 0x48 && text[i+1] == 0x89 && text[i+2] == 0x35 &&
			text[i+7] == 0x48 && text[i+8] == 0x8B && text[i+9] == 0xC6 {
			match = i
			break
		}
	}
	if match < 0 {
		return nil, errors.New("main-frame signature not found")
	}
	scanAddr := textAddr + uintptr(match)
	disp := int32(binary.LittleEndian.Uint32(text[match+3 : match+7]))
	appPtrAddr := uintptr(int64(scanAddr+7) + int64(disp))
	appPtrRaw, err := readUint64(p.handle, appPtrAddr)
	if err != nil || !validPointer(uintptr(appPtrRaw)) {
		return nil, errors.New("main app pointer is not ready")
	}
	vtableRaw, err := readUint64(p.handle, uintptr(appPtrRaw))
	if err != nil || !validPointer(uintptr(vtableRaw)) {
		return nil, errors.New("main app vtable is not ready")
	}
	frameEntry := uintptr(vtableRaw) + 4*8
	originalRaw, err := readUint64(p.handle, frameEntry)
	if err != nil || !validPointer(uintptr(originalRaw)) {
		return nil, errors.New("frame callback pointer is invalid")
	}

	mem, err := virtualAllocEx(p.handle, 0x1000, pageExecuteReadWrite)
	if err != nil {
		return nil, fmt.Errorf("allocate main-thread gate: %w", err)
	}
	g := &mainThreadGate{
		codeAddr: mem, dataAddr: mem + 0x200,
		frameEntry: frameEntry, originalFrame: uintptr(originalRaw),
	}
	code := buildMainThreadGateCode(g.dataAddr)
	if err := writeProcessMemory(p.handle, g.codeAddr, code); err != nil {
		return nil, err
	}
	data := make([]byte, 0x80)
	binary.LittleEndian.PutUint64(data[0x38:], uint64(g.originalFrame))
	if err := writeProcessMemory(p.handle, g.dataAddr, data); err != nil {
		return nil, err
	}
	procFlushInstructionCache.Call(uintptr(p.handle), g.codeAddr, uintptr(len(code)))
	if err := protectedWriteUint64(p.handle, g.frameEntry, uint64(g.codeAddr)); err != nil {
		return nil, fmt.Errorf("hook frame callback: %w", err)
	}
	return g, nil
}

func (g *mainThreadGate) uninstall(p processRef) {
	if g == nil || g.frameEntry == 0 || g.originalFrame == 0 || !processAlive(p.handle) {
		return
	}
	_ = protectedWriteUint64(p.handle, g.frameEntry, uint64(g.originalFrame))
}

func (g *mainThreadGate) call(p processRef, fn uintptr, args [4]uintptr, timeout time.Duration) (uintptr, error) {
	if g == nil || fn == 0 {
		return 0, errors.New("main-thread call gate unavailable")
	}
	flag, err := readUint32(p.handle, g.dataAddr)
	if err != nil {
		return 0, err
	}
	if flag == 1 {
		return 0, errors.New("main-thread call gate is busy")
	}
	buf := make([]byte, 0x30)
	binary.LittleEndian.PutUint64(buf[0x00:], uint64(fn))
	binary.LittleEndian.PutUint64(buf[0x08:], uint64(args[0]))
	binary.LittleEndian.PutUint64(buf[0x10:], uint64(args[1]))
	binary.LittleEndian.PutUint64(buf[0x18:], uint64(args[2]))
	binary.LittleEndian.PutUint64(buf[0x20:], uint64(args[3]))
	// g.data+0x08 is function, +0x10.. are args. buf starts at +0x08.
	if err := writeProcessMemory(p.handle, g.dataAddr+0x08, buf); err != nil {
		return 0, err
	}
	if err := writeUint64(p.handle, g.dataAddr+0x30, 0); err != nil {
		return 0, err
	}
	if err := writeUint32(p.handle, g.dataAddr, 1); err != nil {
		return 0, err
	}
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if !processAlive(p.handle) {
			return 0, errors.New("KH1 exited during main-thread call")
		}
		f, e := readUint32(p.handle, g.dataAddr)
		if e != nil {
			return 0, e
		}
		if f == 2 {
			result, e := readUint64(p.handle, g.dataAddr+0x30)
			_ = writeUint32(p.handle, g.dataAddr, 0)
			return uintptr(result), e
		}
		time.Sleep(time.Millisecond)
	}
	_ = writeUint32(p.handle, g.dataAddr, 0)
	return 0, errors.New("main-thread call timed out")
}

func buildMainThreadGateCode(dataAddr uintptr) []byte {
	code := make([]byte, 0, 192)
	appendBytes := func(v ...byte) { code = append(code, v...) }
	appendU64 := func(v uint64) {
		b := make([]byte, 8)
		binary.LittleEndian.PutUint64(b, v)
		code = append(code, b...)
	}

	// Preserve the original frame callback's argument registers. Earlier builds only kept RCX.
	// A one-shot spawn request overwrote RDX/R8/R9 (and XMM0-3) before the original callback ran,
	// which could corrupt the frame during save/room initialization and cause a later crash.
	appendBytes(0x48, 0x81, 0xEC, 0xA8, 0x00, 0x00, 0x00) // sub rsp,A8h
	appendBytes(0x48, 0x89, 0x8C, 0x24, 0x80, 0, 0, 0)    // [rsp+80] = rcx
	appendBytes(0x48, 0x89, 0x94, 0x24, 0x88, 0, 0, 0)    // [rsp+88] = rdx
	appendBytes(0x4C, 0x89, 0x84, 0x24, 0x90, 0, 0, 0)    // [rsp+90] = r8
	appendBytes(0x4C, 0x89, 0x8C, 0x24, 0x98, 0, 0, 0)    // [rsp+98] = r9
	appendBytes(0xF3, 0x0F, 0x7F, 0x44, 0x24, 0x40)       // movdqu [rsp+40],xmm0
	appendBytes(0xF3, 0x0F, 0x7F, 0x4C, 0x24, 0x50)       // movdqu [rsp+50],xmm1
	appendBytes(0xF3, 0x0F, 0x7F, 0x54, 0x24, 0x60)       // movdqu [rsp+60],xmm2
	appendBytes(0xF3, 0x0F, 0x7F, 0x5C, 0x24, 0x70)       // movdqu [rsp+70],xmm3

	appendBytes(0x49, 0xBA)
	appendU64(uint64(dataAddr))         // mov r10,data
	appendBytes(0x41, 0x83, 0x3A, 0x01) // cmp dword [r10],1
	jnePos := len(code)
	appendBytes(0x0F, 0x85, 0, 0, 0, 0) // jne no_request
	appendBytes(0x49, 0x8B, 0x42, 0x08) // mov rax,[r10+08]
	appendBytes(0x49, 0x8B, 0x4A, 0x10) // mov rcx,[r10+10]
	appendBytes(0x49, 0x8B, 0x52, 0x18) // mov rdx,[r10+18]
	appendBytes(0x4D, 0x8B, 0x42, 0x20) // mov r8,[r10+20]
	appendBytes(0x4D, 0x8B, 0x4A, 0x28) // mov r9,[r10+28]
	appendBytes(0xFF, 0xD0)             // call rax
	appendBytes(0x49, 0x89, 0xC3)       // mov r11,rax
	appendBytes(0x49, 0xBA)
	appendU64(uint64(dataAddr))                  // mov r10,data (callee may clobber it)
	appendBytes(0x4D, 0x89, 0x5A, 0x30)          // mov [r10+30],r11
	appendBytes(0x41, 0xC7, 0x02, 0x02, 0, 0, 0) // flag = 2
	noReq := len(code)
	rel := int32(noReq - (jnePos + 6))
	binary.LittleEndian.PutUint32(code[jnePos+2:jnePos+6], uint32(rel))

	// Restore every original argument before calling KH1's real frame callback.
	appendBytes(0x48, 0x8B, 0x8C, 0x24, 0x80, 0, 0, 0) // rcx
	appendBytes(0x48, 0x8B, 0x94, 0x24, 0x88, 0, 0, 0) // rdx
	appendBytes(0x4C, 0x8B, 0x84, 0x24, 0x90, 0, 0, 0) // r8
	appendBytes(0x4C, 0x8B, 0x8C, 0x24, 0x98, 0, 0, 0) // r9
	appendBytes(0xF3, 0x0F, 0x6F, 0x44, 0x24, 0x40)    // xmm0
	appendBytes(0xF3, 0x0F, 0x6F, 0x4C, 0x24, 0x50)    // xmm1
	appendBytes(0xF3, 0x0F, 0x6F, 0x54, 0x24, 0x60)    // xmm2
	appendBytes(0xF3, 0x0F, 0x6F, 0x5C, 0x24, 0x70)    // xmm3
	appendBytes(0x49, 0x8B, 0x42, 0x38)                // mov rax,[r10+38]
	appendBytes(0xFF, 0xD0)                            // call original frame
	appendBytes(0x48, 0x81, 0xC4, 0xA8, 0, 0, 0)       // add rsp,A8h
	appendBytes(0xC3)
	return code
}

func remoteTextSection(p processRef) (uintptr, int, error) {
	head := make([]byte, 0x2000)
	if err := readProcessMemory(p.handle, p.moduleBase, head); err != nil {
		return 0, 0, err
	}
	if len(head) < 0x100 || head[0] != 'M' || head[1] != 'Z' {
		return 0, 0, errors.New("invalid PE DOS header")
	}
	lfanew := int(binary.LittleEndian.Uint32(head[0x3C:]))
	if lfanew < 0 || lfanew+0x100 >= len(head) || string(head[lfanew:lfanew+4]) != "PE\x00\x00" {
		return 0, 0, errors.New("invalid PE NT header")
	}
	nsec := int(binary.LittleEndian.Uint16(head[lfanew+6:]))
	opt := int(binary.LittleEndian.Uint16(head[lfanew+20:]))
	sec := lfanew + 24 + opt
	for i := 0; i < nsec; i++ {
		off := sec + i*40
		if off+40 > len(head) {
			break
		}
		name := strings.TrimRight(string(head[off:off+8]), "\x00")
		if name != ".text" {
			continue
		}
		virtualSize := int(binary.LittleEndian.Uint32(head[off+8:]))
		virtualAddr := uintptr(binary.LittleEndian.Uint32(head[off+12:]))
		rawSize := int(binary.LittleEndian.Uint32(head[off+16:]))
		size := virtualSize
		if rawSize > 0 && rawSize < size {
			size = rawSize
		}
		return p.moduleBase + virtualAddr, size, nil
	}
	return 0, 0, errors.New(".text section not found")
}

func virtualAllocEx(h syscall.Handle, size uintptr, protect uintptr) (uintptr, error) {
	r, _, e := procVirtualAllocEx.Call(uintptr(h), 0, size, memCommit|memReserve, protect)
	if r == 0 {
		return 0, e
	}
	return r, nil
}

func protectedWriteBytes(h syscall.Handle, addr uintptr, data []byte) error {
	if len(data) == 0 {
		return nil
	}
	var old uintptr
	r, _, e := procVirtualProtectEx.Call(uintptr(h), addr, uintptr(len(data)), pageExecuteReadWrite, uintptr(unsafe.Pointer(&old)))
	if r == 0 {
		return e
	}
	err := writeProcessMemory(h, addr, data)
	var ignored uintptr
	procVirtualProtectEx.Call(uintptr(h), addr, uintptr(len(data)), old, uintptr(unsafe.Pointer(&ignored)))
	procFlushInstructionCache.Call(uintptr(h), addr, uintptr(len(data)))
	return err
}

func protectedWriteUint64(h syscall.Handle, addr uintptr, v uint64) error {
	var old uintptr
	r, _, e := procVirtualProtectEx.Call(uintptr(h), addr, 8, pageExecuteReadWrite, uintptr(unsafe.Pointer(&old)))
	if r == 0 {
		return e
	}
	err := writeUint64(h, addr, v)
	var ignored uintptr
	procVirtualProtectEx.Call(uintptr(h), addr, 8, old, uintptr(unsafe.Pointer(&ignored)))
	procFlushInstructionCache.Call(uintptr(h), addr, 8)
	return err
}

func cloneEntityAlive(p processRef, c *soraCloneState) bool {
	if c == nil || !validPointer(c.ptr) {
		return false
	}
	flags, err := readUint32(p.handle, c.ptr+entityOccFlagOff)
	if err != nil || flags&1 == 0 {
		return false
	}
	id, err := readUint32(p.handle, c.ptr+4)
	return err == nil && id == c.id
}

type restoreQword struct {
	addr  uintptr
	value uint64
}

type restoreDword struct {
	addr  uintptr
	value uint32
}

// The Sora constructor temporarily changes party/player globals. This wrapper runs the
// constructor and restores every temporary global before KH1's normal frame callback resumes.
func buildSpawnRestoreWrapper(spawnFn uintptr, newID uint32, qwords []restoreQword, dwords []restoreDword) []byte {
	code := make([]byte, 0, 256)
	appendBytes := func(v ...byte) { code = append(code, v...) }
	appendU32 := func(v uint32) {
		b := make([]byte, 4)
		binary.LittleEndian.PutUint32(b, v)
		code = append(code, b...)
	}
	appendU64 := func(v uint64) {
		b := make([]byte, 8)
		binary.LittleEndian.PutUint64(b, v)
		code = append(code, b...)
	}

	appendBytes(0x48, 0x83, 0xEC, 0x28) // sub rsp,28h (shadow space + alignment)
	appendBytes(0xB9)                   // mov ecx,newID
	appendU32(newID)
	appendBytes(0x48, 0xB8) // mov rax,spawnFn
	appendU64(uint64(spawnFn))
	appendBytes(0xFF, 0xD0)                   // call rax
	appendBytes(0x48, 0x89, 0x44, 0x24, 0x20) // mov [rsp+20h],rax
	for _, r := range qwords {
		appendBytes(0x48, 0xB8) // mov rax,addr
		appendU64(uint64(r.addr))
		appendBytes(0x48, 0xBA) // mov rdx,value
		appendU64(r.value)
		appendBytes(0x48, 0x89, 0x10) // mov [rax],rdx
	}
	for _, r := range dwords {
		appendBytes(0x48, 0xB8) // mov rax,addr
		appendU64(uint64(r.addr))
		appendBytes(0xC7, 0x00) // mov dword ptr [rax],value
		appendU32(r.value)
	}
	appendBytes(0x48, 0x8B, 0x44, 0x24, 0x20) // mov rax,[rsp+20h]
	appendBytes(0x48, 0x83, 0xC4, 0x28)       // add rsp,28h
	appendBytes(0xC3)                         // ret
	return code
}

// findPartyRegistrationBranch locates the small branch inside the actor constructor that sends
// Sora/party character IDs into the local Player-1/party controller path. v0.6 bypasses only this
// branch while the remote puppet is being constructed, then restores the original bytes immediately.
func findPartyRegistrationBranch(p processRef, spawnAddr uintptr) (uintptr, []byte, []byte, error) {
	const scanSize = 0x900
	buf := make([]byte, scanSize)
	if err := readProcessMemory(p.handle, spawnAddr, buf); err != nil {
		return 0, nil, nil, err
	}
	for i := 0; i+15 <= len(buf); i++ {
		// cmp eax,2 ; ja rel32 ; cmp byte ptr [rdi+6],3 ; jne rel32
		if buf[i] != 0x83 || buf[i+1] != 0xF8 || buf[i+2] != 0x02 ||
			buf[i+3] != 0x0F || buf[i+4] != 0x87 ||
			buf[i+9] != 0x80 || buf[i+10] != 0x7F || buf[i+11] != 0x06 || buf[i+12] != 0x03 ||
			buf[i+13] != 0x0F || buf[i+14] != 0x85 {
			continue
		}
		branch := spawnAddr + uintptr(i+3)
		orig := append([]byte(nil), buf[i+3:i+9]...)
		rel := int32(binary.LittleEndian.Uint32(orig[2:6]))
		target := int64(branch) + 6 + int64(rel)
		newRel64 := target - int64(branch+5)
		if newRel64 < math.MinInt32 || newRel64 > math.MaxInt32 {
			return 0, nil, nil, errors.New("party-registration branch target out of range")
		}
		patch := make([]byte, 6)
		patch[0] = 0xE9 // unconditional near JMP to the original JA target
		binary.LittleEndian.PutUint32(patch[1:5], uint32(int32(newRel64)))
		patch[5] = 0x90
		return branch, orig, patch, nil
	}
	return 0, nil, nil, errors.New("party-registration branch signature not found")
}

func spawnRemoteSoraClone(p processRef, prof Profile, gate *mainThreadGate, remote []byte) (soraCloneState, error) {
	var c soraCloneState
	if gate == nil {
		return c, errors.New("main-thread gate unavailable")
	}
	base := p.moduleBase
	soraRaw, err := readUint64(p.handle, base+prof.SoraObjPointer)
	if err != nil || !validPointer(uintptr(soraRaw)) {
		soraRaw, err = readUint64(p.handle, base+prof.SoraPointer)
	}
	if err != nil || !validPointer(uintptr(soraRaw)) {
		return c, errors.New("local Sora entity pointer unavailable")
	}
	sora := uintptr(soraRaw)
	soraID, err := readUint32(p.handle, sora+4)
	if err != nil {
		return c, err
	}

	count, err := readUint32(p.handle, base+prof.PlacementTableCount)
	if err != nil || count == 0 || count > 4096 {
		return c, fmt.Errorf("placement table count invalid: %d", count)
	}
	tableRaw, err := readUint64(p.handle, base+prof.PlacementTablePtr)
	if err != nil || !validPointer(uintptr(tableRaw)) {
		return c, errors.New("placement table pointer invalid")
	}
	tablePtr := uintptr(tableRaw)
	table := make([]byte, int(count)*placementRecordSize)
	if err := readProcessMemory(p.handle, tablePtr, table); err != nil {
		return c, err
	}

	source := -1
	for i := 0; i < int(count); i++ {
		off := i * placementRecordSize
		if binary.LittleEndian.Uint32(table[off+placementIDOff:]) == soraID {
			source = off
			break
		}
	}
	if source < 0 {
		return c, fmt.Errorf("Sora placement record 0x%X not found in current room", soraID)
	}

	// Preferred path: keep Sora's own character ID/resources/actor setup, but bypass only the
	// constructor branch that registers actor category 3 as local Sora/party. This is much safer
	// than v0.5's duplicate party-Sora and avoids mixing Sora resources with another character.
	branchAddr, branchOrig, branchPatch, branchErr := findPartyRegistrationBranch(p, base+prof.SpawnEntity)
	usePartyBypass := branchErr == nil

	// Fallback for an unexpected executable revision where the constructor signature moved:
	// borrow a non-party actor character ID so KH1's party mapper returns a non-local slot.
	partyIDs := map[uint32]bool{soraID: true}
	for _, ptrOff := range []uintptr{prof.DonaldPointer, prof.GoofyPointer} {
		if raw, e := readUint64(p.handle, base+ptrOff); e == nil && validPointer(uintptr(raw)) {
			if id, e2 := readUint32(p.handle, uintptr(raw)+4); e2 == nil {
				partyIDs[id] = true
			}
		}
	}
	partyCharIDs := map[uint16]bool{}
	for i := 0; i < int(count); i++ {
		off := i * placementRecordSize
		id := binary.LittleEndian.Uint32(table[off+placementIDOff:])
		if partyIDs[id] {
			partyCharIDs[binary.LittleEndian.Uint16(table[off+placementCharIDOff:])] = true
		}
	}
	sourceCharID := binary.LittleEndian.Uint16(table[source+placementCharIDOff:])
	partyCharIDs[sourceCharID] = true
	var donorCharID uint16
	var donorRecordID uint32
	if !usePartyBypass {
		for i := 0; i < int(count); i++ {
			off := i * placementRecordSize
			id := binary.LittleEndian.Uint32(table[off+placementIDOff:])
			category := byte(id >> 16)
			if category != 3 || partyIDs[id] {
				continue
			}
			ch := binary.LittleEndian.Uint16(table[off+placementCharIDOff:])
			if ch == 0 || partyCharIDs[ch] {
				continue
			}
			donorCharID = ch
			donorRecordID = id
			break
		}
		if donorCharID == 0 {
			return c, fmt.Errorf("neutral actor setup unavailable: %v; no non-party donor in room", branchErr)
		}
	}

	newCount := count + 1
	newTable := make([]byte, int(newCount)*placementRecordSize)
	copy(newTable, table)
	rec := newTable[int(count)*placementRecordSize:]
	copy(rec, table[source:source+placementRecordSize])
	newID := uint32(3<<16) | (count & 0xFFFF)
	binary.LittleEndian.PutUint32(rec[placementIDOff:], newID)
	if usePartyBypass {
		binary.LittleEndian.PutUint16(rec[placementCharIDOff:], sourceCharID)
	} else {
		binary.LittleEndian.PutUint16(rec[placementCharIDOff:], donorCharID)
	}
	putFloat32(rec[placementPosXOff:], getFloat32(remote[stX:]))
	putFloat32(rec[placementPosYOff:], getFloat32(remote[stY:]))
	putFloat32(rec[placementPosZOff:], getFloat32(remote[stZ:]))

	remoteTable, err := virtualAllocEx(p.handle, uintptr(len(newTable)), pageReadWrite)
	if err != nil {
		return c, err
	}
	if err := writeProcessMemory(p.handle, remoteTable, newTable); err != nil {
		return c, err
	}

	// Preserve player/party globals. The placement table is intentionally kept extended while
	// the clone exists. Earlier builds restored the table immediately after construction, leaving
	// the live clone with an ID whose placement record no longer existed. Later actor updates could
	// then index past the original table and crash.
	origAlt, _ := readUint64(p.handle, base+prof.SoraPointer)
	origSora, _ := readUint64(p.handle, base+prof.SoraObjPointer)
	origDonald, _ := readUint64(p.handle, base+prof.DonaldPointer)
	origGoofy, _ := readUint64(p.handle, base+prof.GoofyPointer)
	origTable := tableRaw
	origCount := count

	restoreParty := func() {
		_ = writeUint64(p.handle, base+prof.SoraPointer, origAlt)
		_ = writeUint64(p.handle, base+prof.SoraObjPointer, origSora)
		_ = writeUint64(p.handle, base+prof.DonaldPointer, origDonald)
		_ = writeUint64(p.handle, base+prof.GoofyPointer, origGoofy)
	}
	restoreAll := func() {
		_ = writeUint32(p.handle, base+prof.PlacementTableCount, origCount)
		_ = writeUint64(p.handle, base+prof.PlacementTablePtr, origTable)
		restoreParty()
	}

	if err := writeUint64(p.handle, base+prof.PlacementTablePtr, uint64(remoteTable)); err != nil {
		return c, err
	}
	if err := writeUint32(p.handle, base+prof.PlacementTableCount, newCount); err != nil {
		restoreAll()
		return c, err
	}

	// Run a tiny wrapper on KH1's frame thread. It calls the constructor, then restores
	// Sora/party and placement globals inside the same game-thread call before the normal
	// frame function is allowed to continue. External restore() below is a safety fallback.
	qRestores := []restoreQword{
		{base + prof.SoraPointer, origAlt},
		{base + prof.SoraObjPointer, origSora},
		{base + prof.DonaldPointer, origDonald},
		{base + prof.GoofyPointer, origGoofy},
	}
	dRestores := []restoreDword{}
	wrapperCode := buildSpawnRestoreWrapper(base+prof.SpawnEntity, newID, qRestores, dRestores)
	wrapperAddr, err := virtualAllocEx(p.handle, uintptr(len(wrapperCode)+0x40), pageExecuteReadWrite)
	if err != nil {
		restoreAll()
		return c, fmt.Errorf("allocate Sora spawn wrapper: %w", err)
	}
	if err := writeProcessMemory(p.handle, wrapperAddr, wrapperCode); err != nil {
		restoreAll()
		return c, fmt.Errorf("write Sora spawn wrapper: %w", err)
	}
	procFlushInstructionCache.Call(uintptr(p.handle), wrapperAddr, uintptr(len(wrapperCode)))

	partyBranchPatched := false
	if usePartyBypass {
		if err := protectedWriteBytes(p.handle, branchAddr, branchPatch); err != nil {
			restoreAll()
			return c, fmt.Errorf("temporarily bypass party registration: %w", err)
		}
		partyBranchPatched = true
	}
	entity, callErr := gate.call(p, wrapperAddr, [4]uintptr{}, 400*time.Millisecond)
	if partyBranchPatched {
		_ = protectedWriteBytes(p.handle, branchAddr, branchOrig)
	}
	restoreParty()
	if callErr != nil {
		restoreAll()
		return c, callErr
	}
	if !validPointer(entity) {
		restoreAll()
		return c, errors.New("Sora clone constructor returned null")
	}
	flags, err := readUint32(p.handle, entity+entityOccFlagOff)
	if err != nil || flags&1 == 0 {
		restoreAll()
		return c, errors.New("Sora clone entity is not active")
	}
	// Keep the extended placement table active for the lifetime of this clone.
	_ = writeUint64(p.handle, base+prof.PlacementTablePtr, uint64(remoteTable))
	_ = writeUint32(p.handle, base+prof.PlacementTableCount, newCount)

	c.ptr = entity
	c.id = newID
	c.donorCharID = donorCharID
	c.donorRecordID = donorRecordID
	c.partyBypass = usePartyBypass
	c.placementTable = remoteTable
	c.originalTable = origTable
	c.originalCount = origCount
	c.spawnedAt = time.Now()
	c.world = binary.LittleEndian.Uint16(remote[stWorld:])
	c.room = binary.LittleEndian.Uint16(remote[stRoom:])
	for i, off := range []uintptr{0x40, 0x44, 0x48} {
		v, e := readFloat32(p.handle, entity+off)
		if e != nil || float32Bad(v) || math.Abs(float64(v)) < 0.001 {
			v = 1.0
		}
		c.scale[i] = v
	}
	return c, nil
}

func releaseClonePlacement(p processRef, prof Profile, c *soraCloneState) {
	if c == nil || c.placementTable == 0 || c.originalTable == 0 || !processAlive(p.handle) {
		return
	}
	base := p.moduleBase
	curTable, err := readUint64(p.handle, base+prof.PlacementTablePtr)
	if err != nil || uintptr(curTable) != c.placementTable {
		return
	}
	// Reduce count first. A smaller count against the extended table is safe; the reverse order
	// could momentarily expose the original shorter table with the extended count.
	_ = writeUint32(p.handle, base+prof.PlacementTableCount, c.originalCount)
	_ = writeUint64(p.handle, base+prof.PlacementTablePtr, c.originalTable)
	c.placementTable = 0
}

func setCloneHidden(p processRef, c *soraCloneState, hidden bool) {
	if c == nil || !cloneEntityAlive(p, c) || c.hidden == hidden {
		return
	}
	vals := c.scale
	if hidden {
		vals = [3]float32{0, 0, 0}
	}
	_ = writeFloat32(p.handle, c.ptr+0x40, vals[0])
	_ = writeFloat32(p.handle, c.ptr+0x44, vals[1])
	_ = writeFloat32(p.handle, c.ptr+0x48, vals[2])
	c.hidden = hidden
}

func applyRemoteToClone(p processRef, cfg Config, c *soraCloneState, remote []byte) error {
	if c == nil || !cloneEntityAlive(p, c) {
		return errors.New("clone is not active")
	}
	setCloneHidden(p, c, false)
	rx, ry, rz := getFloat32(remote[stX:]), getFloat32(remote[stY:]), getFloat32(remote[stZ:])
	if !finite3(rx, ry, rz) {
		return nil
	}
	x, ex := readFloat32(p.handle, c.ptr+0x10)
	y, ey := readFloat32(p.handle, c.ptr+0x14)
	z, ez := readFloat32(p.handle, c.ptr+0x18)
	if ex != nil || ey != nil || ez != nil {
		return errors.New("clone position unreadable")
	}
	dx, dy, dz := rx-x, ry-y, rz-z
	d2 := dx*dx + dy*dy + dz*dz
	t := cfg.Smoothing
	if d2 > cfg.SnapDistance*cfg.SnapDistance {
		t = 1
	}
	if err := writeFloat32(p.handle, c.ptr+0x10, x+dx*t); err != nil {
		return err
	}
	if err := writeFloat32(p.handle, c.ptr+0x14, y+dy*t); err != nil {
		return err
	}
	if err := writeFloat32(p.handle, c.ptr+0x18, z+dz*t); err != nil {
		return err
	}

	// Rotation is part of the entity transform, independent from animation/controller state.
	// Syncing it directly stops the remote puppet from facing this PC's local-input direction.
	rot := []struct {
		state  int
		entity uintptr
	}{
		{stRotW, 0x20}, {stRotX, 0x28}, {stRotY, 0x30}, {stRotZ, 0x38},
	}
	for _, ro := range rot {
		v := getFloat32(remote[ro.state:])
		if !float32Bad(v) && math.Abs(float64(v)) < 1000000 {
			_ = writeFloat32(p.handle, c.ptr+ro.entity, v)
		}
	}

	if cfg.SyncAnimation && (c.spawnedAt.IsZero() || time.Since(c.spawnedAt) >= time.Duration(cfg.AnimationWarmupMS)*time.Millisecond) {
		remoteAnim := byte(binary.LittleEndian.Uint32(remote[stAnim:]))
		remoteForce := byte(binary.LittleEndian.Uint32(remote[stForceAnim:]))
		remoteTime := getFloat32(remote[stAnimTime:])
		remoteSpeed := getFloat32(remote[stAnimSpeed:])
		remoteAir := getFloat32(remote[stAirborne:])

		desiredForce := remoteAnim
		if remoteForce > 0x0A {
			desiredForce = remoteForce
		}

		// Important: only start a motion when the REMOTE player changes motion. v0.5 also
		// reacted when KH1 locally rewrote the clone, which restarted run/attack every frame
		// and produced the rapid footstep sound.
		if !c.animInitialized || c.lastRemoteAnim != remoteAnim || c.lastRemoteForce != desiredForce {
			_ = writeUint8(p.handle, c.ptr+0x164, remoteAnim)
			_ = writeUint8(p.handle, c.ptr+0x168, desiredForce)
			if !float32Bad(remoteTime) && remoteTime >= 0 && remoteTime < 100000 {
				_ = writeFloat32(p.handle, c.ptr+0x16C, remoteTime)
			}
			if !float32Bad(remoteSpeed) && math.Abs(float64(remoteSpeed)) < 100 {
				_ = writeFloat32(p.handle, c.ptr+0x284, remoteSpeed)
			}
			c.lastRemoteAnim = remoteAnim
			c.lastRemoteForce = desiredForce
			c.animInitialized = true
			c.lastAnimApply = time.Now()
		}

		// Airborne state can change inside one jump animation, so this is safe to mirror
		// continuously without restarting the motion or its sound events.
		if !float32Bad(remoteAir) && math.Abs(float64(remoteAir)) < 100000 {
			_ = writeFloat32(p.handle, c.ptr+0x70, remoteAir)
		}
	}

	return nil
}

func receiveLoop(conn *net.UDPConn, cfg Config, out chan<- packet) {
	buf := make([]byte, 32+stateSize)
	expectedHash := hashSession(cfg.SessionKey)
	otherID := uint32(1)
	if cfg.PlayerID == 1 {
		otherID = 2
	}
	for {
		n, _, err := conn.ReadFromUDP(buf)
		if err != nil {
			return
		}
		pkt, ok := decodePacket(buf[:n])
		if !ok || pkt.Magic != magic || pkt.Protocol != protocol || pkt.SessionHash != expectedHash || pkt.PlayerID != otherID {
			continue
		}
		select {
		case out <- pkt:
		default:
		}
	}
}

func encodePacket(p packet) []byte {
	b := make([]byte, 32+stateSize)
	binary.LittleEndian.PutUint32(b[0:], p.Magic)
	binary.LittleEndian.PutUint32(b[4:], p.Protocol)
	binary.LittleEndian.PutUint64(b[8:], p.SessionHash)
	binary.LittleEndian.PutUint32(b[16:], p.PlayerID)
	binary.LittleEndian.PutUint32(b[20:], p.Profile)
	binary.LittleEndian.PutUint32(b[24:], p.Sequence)
	copy(b[32:], p.State[:])
	return b
}

func decodePacket(b []byte) (packet, bool) {
	var p packet
	if len(b) < 32+stateSize {
		return p, false
	}
	p.Magic = binary.LittleEndian.Uint32(b[0:])
	p.Protocol = binary.LittleEndian.Uint32(b[4:])
	p.SessionHash = binary.LittleEndian.Uint64(b[8:])
	p.PlayerID = binary.LittleEndian.Uint32(b[16:])
	p.Profile = binary.LittleEndian.Uint32(b[20:])
	p.Sequence = binary.LittleEndian.Uint32(b[24:])
	copy(p.State[:], b[32:32+stateSize])
	return p, true
}

func hashSession(s string) uint64 {
	h := sha256.Sum256([]byte(s))
	return binary.LittleEndian.Uint64(h[:8])
}

func loadConfig(path string) (Config, error) {
	cfg := Config{
		ListenPort: 37171, TargetInstance: 1, TargetPID: 0, PlayerID: 1, SessionKey: "kh1-coop", SendHz: 30, Profile: 0,
		Proxy: "donald", Smoothing: 0.42, SnapDistance: 900.0, HideDuringCutscene: true, SyncAnimation: false, SpawnDelayMS: 3500, AnimationWarmupMS: 1500, VisualSync: true, SpawnOnly: false, ExistingActorOnly: true, ForcePartyMember: true, ReservedParty: "donald",
	}
	f, err := os.Open(path)
	if err != nil {
		return cfg, fmt.Errorf("open %s: %w", path, err)
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, ";") || strings.HasPrefix(line, "[") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.ToLower(strings.TrimSpace(parts[0]))
		val := strings.TrimSpace(parts[1])
		switch key {
		case "listen_port":
			n, _ := strconv.Atoi(val)
			if n > 0 && n <= 65535 {
				cfg.ListenPort = n
			}
		case "target_instance":
			n, _ := strconv.Atoi(val)
			if n >= 1 && n <= 16 {
				cfg.TargetInstance = n
			}
		case "target_pid":
			n, _ := strconv.ParseUint(val, 10, 32)
			cfg.TargetPID = uint32(n)
		case "peer_addr":
			cfg.PeerAddr = val
		case "player_id":
			n, _ := strconv.Atoi(val)
			if n == 1 || n == 2 {
				cfg.PlayerID = uint32(n)
			}
		case "session_key":
			if val != "" {
				cfg.SessionKey = val
			}
		case "send_hz":
			n, _ := strconv.Atoi(val)
			if n >= 10 && n <= 60 {
				cfg.SendHz = n
			}
		case "profile":
			n, _ := strconv.Atoi(val)
			if n >= 0 && n <= 3 {
				cfg.Profile = uint32(n)
			}
		case "proxy":
			v := strings.ToLower(val)
			if v == "auto" || v == "goofy" || v == "donald" {
				cfg.Proxy = v
			}
		case "smoothing":
			if f, e := strconv.ParseFloat(val, 32); e == nil {
				cfg.Smoothing = float32(f)
			}
		case "snap_distance":
			if f, e := strconv.ParseFloat(val, 32); e == nil {
				cfg.SnapDistance = float32(f)
			}
		case "hide_during_cutscene":
			v := strings.ToLower(val)
			cfg.HideDuringCutscene = !(v == "0" || v == "false" || v == "no")
		case "sync_animation":
			v := strings.ToLower(val)
			cfg.SyncAnimation = !(v == "0" || v == "false" || v == "no")
		case "spawn_delay_ms":
			n, _ := strconv.Atoi(val)
			if n >= 500 && n <= 15000 {
				cfg.SpawnDelayMS = n
			}
		case "animation_warmup_ms":
			n, _ := strconv.Atoi(val)
			if n >= 0 && n <= 10000 {
				cfg.AnimationWarmupMS = n
			}
		case "visual_sync":
			v := strings.ToLower(val)
			cfg.VisualSync = !(v == "0" || v == "false" || v == "no" || v == "off")
		case "spawn_only":
			v := strings.ToLower(val)
			cfg.SpawnOnly = !(v == "0" || v == "false" || v == "no" || v == "off")
		case "existing_actor_only":
			v := strings.ToLower(val)
			cfg.ExistingActorOnly = !(v == "0" || v == "false" || v == "no" || v == "off")
		case "force_party_member":
			v := strings.ToLower(val)
			cfg.ForcePartyMember = !(v == "0" || v == "false" || v == "no" || v == "off")
		case "reserved_party":
			v := strings.ToLower(val)
			if v == "donald" || v == "goofy" {
				cfg.ReservedParty = v
			}
		}
	}
	if err := scanner.Err(); err != nil {
		return cfg, err
	}
	if cfg.PlayerID != 1 && cfg.PlayerID != 2 {
		return cfg, errors.New("player_id must be 1 or 2")
	}
	if cfg.Smoothing < 0.05 {
		cfg.Smoothing = 0.05
	}
	if cfg.Smoothing > 1 {
		cfg.Smoothing = 1
	}
	if cfg.SnapDistance < 100 {
		cfg.SnapDistance = 100
	}
	return cfg, nil
}

func findProcessTarget(name string, targetPID uint32, targetInstance int) (processRef, error) {
	pids, err := findProcessIDs(name)
	if err != nil {
		return processRef{}, err
	}
	if targetPID != 0 {
		found := false
		for _, pid := range pids {
			if pid == targetPID {
				found = true
				break
			}
		}
		if !found {
			return processRef{}, fmt.Errorf("target PID %d is not a running KH1 process", targetPID)
		}
		return openProcessRef(targetPID, name)
	}
	if targetInstance < 1 {
		targetInstance = 1
	}
	if len(pids) < targetInstance {
		return processRef{}, fmt.Errorf("waiting for KH1 instance %d; currently %d running", targetInstance, len(pids))
	}
	return openProcessRef(pids[targetInstance-1], name)
}

func findProcessIDs(name string) ([]uint32, error) {
	snap, _, e := procCreateToolhelp32Snapshot.Call(th32csSnapProcess, 0)
	if snap == uintptr(syscall.InvalidHandle) || snap == 0 {
		return nil, e
	}
	defer closeHandle(syscall.Handle(snap))
	var pe processEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	var pids []uint32
	r, _, _ := procProcess32FirstW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	for r != 0 {
		exe := syscall.UTF16ToString(pe.ExeFile[:])
		if strings.EqualFold(exe, name) {
			pids = append(pids, pe.ProcessID)
		}
		r, _, _ = procProcess32NextW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	}
	sort.Slice(pids, func(i, j int) bool { return pids[i] < pids[j] })
	if len(pids) == 0 {
		return nil, errors.New("process not found")
	}
	return pids, nil
}

func openProcessRef(pid uint32, name string) (processRef, error) {
	rights := uintptr(processQueryInfo | processVMOperation | processVMRead | processVMWrite | synchronize)
	h, _, err := procOpenProcess.Call(rights, 0, uintptr(pid))
	if h == 0 {
		return processRef{}, err
	}
	base, path, err := findMainModule(pid, name)
	if err != nil {
		closeHandle(syscall.Handle(h))
		return processRef{}, err
	}
	return processRef{pid: pid, handle: syscall.Handle(h), moduleBase: base, exePath: path}, nil
}

func findMainModule(pid uint32, name string) (uintptr, string, error) {
	snap, _, e := procCreateToolhelp32Snapshot.Call(th32csSnapModule|th32csSnapModule32, uintptr(pid))
	if snap == uintptr(syscall.InvalidHandle) || snap == 0 {
		return 0, "", e
	}
	defer closeHandle(syscall.Handle(snap))
	var me moduleEntry32
	me.Size = uint32(unsafe.Sizeof(me))
	r, _, _ := procModule32FirstW.Call(snap, uintptr(unsafe.Pointer(&me)))
	for r != 0 {
		mod := syscall.UTF16ToString(me.SzModule[:])
		if strings.EqualFold(mod, name) {
			return me.ModBaseAddr, syscall.UTF16ToString(me.SzExePath[:]), nil
		}
		r, _, _ = procModule32NextW.Call(snap, uintptr(unsafe.Pointer(&me)))
	}
	return 0, "", errors.New("main module not found")
}

func validPointer(p uintptr) bool    { return p > 0x10000 && uint64(p) < 0x0000800000000000 }
func finite3(a, b, c float32) bool   { return !float32Bad(a) && !float32Bad(b) && !float32Bad(c) }
func float32Bad(v float32) bool      { return math.IsNaN(float64(v)) || math.IsInf(float64(v), 0) }
func putFloat32(b []byte, v float32) { binary.LittleEndian.PutUint32(b, math.Float32bits(v)) }
func getFloat32(b []byte) float32    { return math.Float32frombits(binary.LittleEndian.Uint32(b)) }

func readProcessMemory(h syscall.Handle, addr uintptr, out []byte) error {
	if len(out) == 0 {
		return nil
	}
	var n uintptr
	r, _, e := procReadProcessMemory.Call(uintptr(h), addr, uintptr(unsafe.Pointer(&out[0])), uintptr(len(out)), uintptr(unsafe.Pointer(&n)))
	if r == 0 {
		return e
	}
	if n != uintptr(len(out)) {
		return fmt.Errorf("partial ReadProcessMemory: %d/%d bytes", n, len(out))
	}
	return nil
}
func writeProcessMemory(h syscall.Handle, addr uintptr, data []byte) error {
	if len(data) == 0 {
		return nil
	}
	var n uintptr
	r, _, e := procWriteProcessMemory.Call(uintptr(h), addr, uintptr(unsafe.Pointer(&data[0])), uintptr(len(data)), uintptr(unsafe.Pointer(&n)))
	if r == 0 {
		return e
	}
	if n != uintptr(len(data)) {
		return fmt.Errorf("partial WriteProcessMemory: %d/%d bytes", n, len(data))
	}
	return nil
}
func readUint8(h syscall.Handle, addr uintptr) (uint8, error) {
	b := make([]byte, 1)
	if e := readProcessMemory(h, addr, b); e != nil {
		return 0, e
	}
	return b[0], nil
}
func readUint32(h syscall.Handle, addr uintptr) (uint32, error) {
	b := make([]byte, 4)
	if e := readProcessMemory(h, addr, b); e != nil {
		return 0, e
	}
	return binary.LittleEndian.Uint32(b), nil
}
func readUint64(h syscall.Handle, addr uintptr) (uint64, error) {
	b := make([]byte, 8)
	if e := readProcessMemory(h, addr, b); e != nil {
		return 0, e
	}
	return binary.LittleEndian.Uint64(b), nil
}
func readFloat32(h syscall.Handle, addr uintptr) (float32, error) {
	v, e := readUint32(h, addr)
	if e != nil {
		return 0, e
	}
	return math.Float32frombits(v), nil
}
func writeUint8(h syscall.Handle, addr uintptr, v uint8) error {
	return writeProcessMemory(h, addr, []byte{v})
}
func writeUint32(h syscall.Handle, addr uintptr, v uint32) error {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, v)
	return writeProcessMemory(h, addr, b)
}
func writeUint64(h syscall.Handle, addr uintptr, v uint64) error {
	b := make([]byte, 8)
	binary.LittleEndian.PutUint64(b, v)
	return writeProcessMemory(h, addr, b)
}
func writeFloat32(h syscall.Handle, addr uintptr, v float32) error {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, math.Float32bits(v))
	return writeProcessMemory(h, addr, b)
}

func processAlive(h syscall.Handle) bool {
	r, _, _ := procWaitForSingleObject.Call(uintptr(h), 0)
	return r == waitTimeout
}
func closeHandle(h syscall.Handle) {
	if h != 0 && h != syscall.InvalidHandle {
		procCloseHandle.Call(uintptr(h))
	}
}
func fatal(err error) { fmt.Fprintf(os.Stderr, "KHCoop Bridge error: %v\n", err); os.Exit(1) }
