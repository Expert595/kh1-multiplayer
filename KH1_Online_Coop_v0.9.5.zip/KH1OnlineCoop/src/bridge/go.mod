module khcoopbridge

go 1.20
