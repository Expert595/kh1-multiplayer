@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Configure-Online.ps1"
if errorlevel 1 (
  echo.
  echo Configuration failed. Read the error above.
)
pause
