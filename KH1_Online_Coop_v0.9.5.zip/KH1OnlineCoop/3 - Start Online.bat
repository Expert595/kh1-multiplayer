@echo off
cd /d "%~dp0"
if not exist "%~dp0bin\KHCoopBridge.exe" (
  echo bin\KHCoopBridge.exe is missing.
  pause
  exit /b 1
)
if not exist "%~dp0config\khcoop.ini" (
  echo config\khcoop.ini is missing.
  pause
  exit /b 1
)
start "KH1 Coop Bridge" "%~dp0bin\KHCoopBridge.exe" -config "%~dp0config\khcoop.ini"
echo KH1 Coop bridge started. Launch KINGDOM HEARTS FINAL MIX normally.
